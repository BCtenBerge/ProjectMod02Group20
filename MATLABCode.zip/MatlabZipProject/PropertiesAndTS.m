clc, clear, close all
%% Calculating of all properties of all flows using XSteam where possible
% Bram ten Berge - December 2024

% Importing XSteam 
addpath Functions\
addpath Functions\'XSteam & GasProperties'\

% Initiate all properties we want to know to orderly structure them
% in the structure. Please bear in mind, when opening the table in matlab,
% the numbers of the row line up with the number of the of flow of the
% system, except for the reference state, 5', 12A and 12B. These will be
% rows 27-30 respectively.


for i=1:30
    flow(i).m_dot = NaN;
    flow(i).p = NaN;
    flow(i).t = NaN;
    flow(i).h = NaN;
    flow(i).s = NaN;
    flow(i).x = NaN;
    flow(i).ex_dot = NaN;
    flow(i).Exergy = NaN;
    flow(i).Energy = NaN;
end



% Define the given reference state, T=15C and P=1bar
 
flow(27).m_dot = NaN;
flow(27).p = 1;
flow(27).t = 15;
flow(27).h = XSteam('h_pt',flow(27).p,flow(27).t);
flow(27).s = XSteam('s_ph',flow(27).p,flow(27).h);
flow(27).x = NaN;


%% List of known values
% First we define every known value, such that we can calculate all unknown
% properties of all flows.


% Some other given variables we have to keep in mind:
%       - Generator efficiency = 0.97, Power output turbine 1 = 40MW, Power output turbine 2 = 60MW
%       - Pump 1 & 2 are isentropic

flow(1).m_dot = 235;
flow(1).p = 9.0;
flow(1).x = 0.80;
flow(2).x = 1;
flow(3).m_dot = 82;
flow(4).p = 0.1;
flow(28).x = 0;
flow(6).p = 0.08;
flow(6).x = 0;
flow(7).p = 1.0;
flow(8).m_dot = 2010;
flow(8).p = 1.0;
flow(11).m_dot = 1;
flow(29).x = 0.95;
flow(13).m_dot = 51.3;
flow(13).p = 2.6;
flow(13).x = 0.7;
flow(14).x = 1;
flow(15).p = 0.1;
flow(16).p = 0.1;
flow(17).p = 1.0;
flow(17).t = 22;
flow(18).m_dot = 3406;
flow(18).p = 5.0;
flow(20).p = 1.0;
flow(23).x = 0;
flow(25).x = 0;

% Known Efficiencies & Power outputs
w.turbine1 = 40E3;
w.turbine2 = 60E3;
eta.gen = 0.97;

%% Steam seperator 1 & 2
% Firstly we start with gathering all properties of flow 1 & 13, we can do this
% as we know that flow are in mixture phase and have certain pressures.
% Therefore, the temperature is the saturation temperature and with that we
% have Pressure, Temperature and quality and let XSteam calculate the rest.
flow(1).t = XSteam('Tsat_p',flow(1).p);
flow(1).h = XSteam('h_px',flow(1).p,flow(1).x); 
flow(1).s = XSteam('s_ph',flow(1).p,flow(1).h);


flow(13).t = XSteam('Tsat_p',flow(13).p);
flow(13).h = XSteam('h_px',flow(13).p,flow(13).x);
flow(13).s = XSteam('s_ph',flow(13).p,flow(13).h);


% Then, as it is given that the seperators seperates the mixture input into
% two streams one of which is fully saturated liquid, the other is fully
% saturated vapor we can calculate all the properties of flows 2, 21, 14
% and 19.

% In steam seperator 1, as the quality of flow 1 = 0.8, we know that 80% of
% the massflow coming into the steam seperator is vapor. The same
% calculation is used for the mass flows in and out of steam seperator 2
flow(2).m_dot = flow(1).x * flow(1).m_dot;
flow(21).m_dot = flow(1).m_dot - flow(2).m_dot;

flow(14).m_dot = flow(13).x * flow(13).m_dot;
flow(19).m_dot = flow(13).m_dot - flow(14).m_dot;

% All other properties are known, as we know the pressure of all of these
% flows is equal to the pressure prior to the steam seperator, because the 
% seperator is assumed to be isobaric, isentropic and adiabatic 
% We also know that all outcoming flows are saturated liquid or vapor.

flow(2).p = flow(1).p;
flow(2).t = flow(1).t;
flow(2).h = XSteam('h_px',flow(2).p,flow(2).x);
flow(2).s = XSteam('s_ph',flow(2).p,flow(2).h);

flow(21).p = flow(1).p;
flow(21).t = flow(1).t;
flow(21).x = 0;
flow(21).h = XSteam('h_px',flow(21).p,flow(21).x);
flow(21).s = XSteam('s_ph',flow(21).p,flow(21).h);


flow(14).p = flow(13).p;
flow(14).t = flow(13).t;
flow(14).h = XSteam('h_px',flow(14).p,flow(14).x);
flow(14).s = XSteam('s_ph',flow(14).p,flow(14).h);

flow(19).p = flow(13).p;
flow(19).t = flow(13).t;
flow(19).x = 0;
flow(19).h = XSteam('h_px',flow(19).p,flow(19).x);
flow(19).s = XSteam('s_ph',flow(19).p,flow(19).h);

% For flows 3, 12 and 11 all the properties, except massflow are the same
% as flow 2. We only need to calculate the massflow of flow 12, all other
% massflows are given or previously calculated.

flow(11).p = flow(2).p;
flow(11).t = flow(2).t;
flow(11).h = flow(2).h;
flow(11).s = flow(2).s;
flow(11).x = flow(2).x;

flow(3).p = flow(2).p;
flow(3).t = flow(2).t;
flow(3).h = flow(2).h;
flow(3).s = flow(2).s;
flow(3).x = flow(2).x;

flow(12).m_dot = flow(2).m_dot - flow(11).m_dot - flow(3).m_dot;
flow(12).p = flow(2).p;
flow(12).t = flow(2).t;
flow(12).h = flow(2).h;
flow(12).s = flow(2).s;
flow(12).x = flow(2).x;

%% Turbine 1
% As we know the power output of the generator, we can calculate the
% enthalpy of flow 4 and then we can find all other properties as we also
% already have the pressure of flow 4.

flow(4).m_dot = flow(3).m_dot;
flow(4).h = flow(3).h - (w.turbine1 / flow(4).m_dot);
flow(4).x = (flow(4).h - XSteam('h_px',flow(4).p,0)) / (XSteam('h_px',flow(4).p,1) - XSteam('h_px',flow(4).p,0));
flow(4).t = XSteam('tsat_p',0.1);
flow(4).s = XSteam('s_ph',flow(4).p,flow(4).h);

%% Turbine 2
% As we know the pressure of 14 and we know that the pressure of 12A (keep in mind, 29 in this code) must
% be the same (as it's a mixing chamger), we also know that 12A has a
% quality, meaning we have everything to find all properties of 12A. With
% these properties we can determine the power output of turbine 2A and then
% also of 2B as we know the overall power output of the entire turbine.

flow(29).m_dot = flow(12).m_dot;
flow(29).p = flow(14).p;
flow(29).t = XSteam('tsat_p', flow(29).p);
flow(29).h = XSteam('h_px',flow(29).p,flow(29).x);
flow(29).s = XSteam('s_ph', flow(29).p, flow(29).h);
w.turbine2A = (flow(12).h - flow(29).h) * flow(29).m_dot;
w.turbine2B = w.turbine2 - w.turbine2A;

% Mixing chamber 12A & 14; we know that the pressure remains the same for
% 12B (30 in matlab), the enthalpy is then calculated taking the weighted
% average of both incoming flows.

flow(30).m_dot = flow(29).m_dot + flow(14).m_dot;
flow(30).p = flow(29).p;
flow(30).t = flow(29).t;
flow(30).h = (flow(29).m_dot * flow(29).h + flow(14).m_dot * flow(14).h) / flow(30).m_dot;
flow(30).x = (flow(30).h - XSteam('h_px',flow(30).p,0)) / (XSteam('h_px',flow(30).p,1) - XSteam('h_px',flow(30).p,0));
flow(30).s = XSteam('s_ph',flow(30).p,flow(30).h);

% When we know all the properties of flow 12B, then we can find the
% properties of 15 using the power output of turbine 2B.
flow(15).m_dot = flow(30).m_dot;
flow(15).h = flow(30).h - (w.turbine2B / flow(15).m_dot);
flow(15).x = (flow(15).h - XSteam('h_px',flow(15).p,0)) / (XSteam('h_px',flow(15).p,1) - XSteam('h_px',flow(15).p,0));
flow(15).t = XSteam('tsat_p', flow(15).p);
flow(15).s = XSteam('s_ph', flow(15).p, flow(15).h);



%% Condenser 2
% We know all values of flow 15 and enough properties of flow 17 & 18 to
% calculate everything, as we can assume pump 2 te be isentropic.

flow(17).m_dot = flow(18).m_dot + flow(8).m_dot;
flow(17).h = XSteam('h_pt', flow(17).p, flow(17).t);
flow(17).s = XSteam('s_ph', flow(17).p, flow(17).h);

flow(18).s = flow(17).s;
flow(18).h = XSteam('h_ps',flow(18).p,flow(18).s);
flow(18).t = XSteam('t_ph', flow(18).p, flow(18).h);

% Then, we can find the enthalpy of flow 16 by taking the weighted average.
% The rest is calculated using the given pressure.
flow(16).m_dot = flow(18).m_dot + flow(15).m_dot;
flow(16).h = (flow(18).m_dot * flow(18).h + flow(15).m_dot * flow(15).h) / flow(16).m_dot;
flow(16).t = XSteam('t_ph', flow(16).p, flow(16).h);
flow(16).s = XSteam('s_ph', flow(16).p, flow(16).h);
flow(16).x = NaN;

%% Condenser 1
% Flow 5' (28) has the same pressure as flow 4, because the condenser can
% be assumed isobaric. Furtheremore, it is given that the outgoing flow is
% saturated liquid and with that all other properties can be calculated.
flow(28).m_dot = flow(4).m_dot;
flow(28).p = flow(4).p;
flow(28).t = XSteam('tsat_p', flow(28).p);
flow(28).h = XSteam('h_px', flow(28).p, flow(28).x);
flow(28).s = XSteam('s_ph', flow(28).p, flow(28).h);

% Flow 16 & 5' (28) are then combined into flow 5, the enthalpy is once
% again found using the weighted average and the pressure remaind the same.
flow(5).m_dot = flow(16).m_dot + flow(28).m_dot;
flow(5).p = flow(16).p;
flow(5).h = (flow(28).m_dot * flow(28).h + flow(16).m_dot * flow(16).h) / flow(5).m_dot;
flow(5).t = XSteam('t_ph', flow(5).p, flow(5).h);
flow(5).s = XSteam('s_ph', flow(5).p, flow(5).h);
w.condenser1out = flow(4).m_dot * flow(4).h - flow(28).m_dot * flow(28).h; % The amound of heat that is transferred from flow 4 to flow 8, resulting in flow 5' and 9.

% Then the properties of other flows entering and leaving the condenser
% have to be calculated. Flow 8 is the same as 17, except for massflow,
% which was a given variable. The properties of flow 9 are calculated using
% the amount of heat that gets tranferred from flow 4 to flow 8.
flow(8).t = flow(17).t;
flow(8).h = flow(17).h;
flow(8).s = flow(17).s;

flow(9).m_dot = flow(8).m_dot;
flow(9).p = flow(8).p;
flow(9).h = (flow(8).m_dot * flow(8).h + w.condenser1out) / flow(9).m_dot;
flow(9).t = XSteam('t_ph', flow(9).p, flow(9).h);
flow(9).s = XSteam('s_ph', flow(9).p, flow(9).h);


%% Deaerator
% We have two properties of flow 6, so we can calculate the other using
% XSteam.

flow(6).m_dot = flow(5).m_dot + flow(11).m_dot;
flow(6).h = XSteam('h_px', flow(6).p, flow(6).x);
flow(6).t = XSteam('tsat_p', flow(6).p);
flow(6).s = XSteam('s_ph', flow(6).p, flow(6).h);
w.dearator = flow(5).h * flow(5).m_dot + flow(11).m_dot * flow(11).h - flow(6).m_dot * flow(6).h; % Heat loss of the deaerator.

%% Pump 2
% As said before, both pumps can be assumed isentropic, so the entropy is
% found. As the pressure was already given, all other properties can be
% calculated.
flow(7).m_dot = flow(6).m_dot;
flow(7).s = flow(6).s;
flow(7).h = XSteam('h_ps',flow(7).p,flow(7).s);
flow(7).t = XSteam('t_ph', flow(7).p, flow(7).h);

% Flow 10 is the sum of flow 7 & 9, the pressure remains the same and the
% enthalpy is calculated using the weighted average.
flow(10).m_dot = flow(9).m_dot + flow(7).m_dot;
flow(10).p = flow(9).p;
flow(10).h = ((flow(7).m_dot * flow(7).h + flow(9).m_dot * flow(9).h)) / flow(10).m_dot;
flow(10).t = XSteam('t_ph', flow(10).p, flow(10).h);
flow(10).s = XSteam('s_ph', flow(10).p, flow(10).h);


%% All expansion valves and steam seperators 3&4
% For a valve, it is known that the enthalpy does not change. Furthermore,
% it is given that the pressure after expansion should be atmospheric
% pressure for both flow 20 & flow 22. The quality is calculated using the
% saturated liquid and vapor values for enthalpy.

flow(20).m_dot = flow(19).m_dot;
flow(20).h = flow(19).h;
flow(20).x = (flow(20).h - XSteam('h_px',flow(20).p,0)) / (XSteam('h_px',flow(20).p,1) - XSteam('h_px',flow(20).p,0));
flow(20).t = XSteam('tsat_p', flow(20).p);
flow(20).s = XSteam('s_ph', flow(20).p, flow(20).h);

flow(22).p = 1; 
flow(22).m_dot = flow(21).m_dot;
flow(22).h = flow(21).h;
flow(22).x = (flow(22).h - XSteam('h_px',flow(22).p,0)) / (XSteam('h_px',flow(22).p,1) - XSteam('h_px',flow(22).p,0));
flow(22).t = XSteam('tsat_p', flow(22).p);
flow(22).s = XSteam('s_ph', flow(22).p, flow(22).h);


% When all values of 20 & 22 are known, the last step are the steam
% seperators. The same principle is followed as the other steam seperators
% prior in the cycle. One flow is saturated vapor, the other saturated
% liquid.
flow(24).m_dot = flow(22).m_dot * flow(22).x;
flow(24).p = flow(22).p;
flow(24).x = 1;
flow(24).h = XSteam('h_px',flow(24).p,flow(24).x);
flow(24).t = XSteam('tsat_p',flow(24).p);
flow(24).s = XSteam('s_ph', flow(24).p, flow(24).h);

flow(23).m_dot = flow(22).m_dot - flow(24).m_dot;
flow(23).p = flow(22).p;
flow(23).x = 0;
flow(23).h = XSteam('h_px',flow(23).p,flow(23).x);
flow(23).t = XSteam('tsat_p',flow(23).p);
flow(23).s = XSteam('s_ph',flow(23).p, flow(23).h);


flow(26).m_dot = flow(20).m_dot * flow(20).x;
flow(26).p = flow(20).p;
flow(26).x = 1;
flow(26).h = XSteam('h_px',flow(26).p,flow(26).x);
flow(26).t = XSteam('tsat_p',flow(26).p);
flow(26).s = XSteam('s_ph', flow(26).p, flow(26).h);


flow(25).m_dot = flow(20).m_dot - flow(26).m_dot;
flow(25).p = flow(20).p;
flow(25).x = 0;
flow(25).h = XSteam('h_px',flow(25).p,flow(25).x);
flow(25).t = XSteam('tsat_p',flow(25).p);
flow(25).s = XSteam('s_ph', flow(25).p, flow(25).h);


%% Exergy & Energy calculation
% The exergy is calculated using the formula for the exergy of a flow,
% \psi = dh - T_0 * ds, the reference state is defined as flow 27. 
% The energy is calculated using enthalpy.

for i=1:30
    flow(i).ex_dot = (flow(i).h - flow(27).h) - (flow(27).t + 273.15) * (flow(i).s - flow(27).s);
    flow(i).Exergy = flow(i).ex_dot * flow(i).m_dot;
    flow(i).Energy = flow(i).h * flow(i).m_dot;

end

%% Isentropic efficiencies Turbines
% To find out what the isentropic efficiencies are, the enthalpy
% needs to be found if the turbine were to be isentropic. 
flowisentropic(4).h = XSteam('h_ps',flow(4).p,flow(3).s);
w.isentropic.turb1= (flow(3).h - flowisentropic(4).h) * flow(3).m_dot;
eta.is.turbine1 = w.turbine1 / w.isentropic.turb1;

flowisentropic(28).h = XSteam('h_ps',flow(29).p,flow(12).s);
w.isentropic.turb2HPT = (flow(12).h - flowisentropic(28).h) * flow(12).m_dot;
eta.is.turbine2HPT = w.turbine2A / w.isentropic.turb2HPT;

flowisentropic(29).h = XSteam('h_ps',flow(15).p,flow(30).s);
w.isentropic.turb2LPT= (flow(30).h - flowisentropic(29).h) * flow(30).m_dot;
eta.is.turbine2LPT = w.turbine2B / w.isentropic.turb2LPT;


%% Ts diagram
% In this section the Ts diagram is made using a couple of functions.
figure 
hold on

% Plotting VaporDome and Isobars
pl(1) = plotVaporDomeTs;
pl(2) = plotIsobarsTs([0.1,1,2.6,9],0.01,10);
h = findobj('Color','k');

for i=1:4
    h(i).LineStyle = '--';
    h(i).Color = [0.7 0.7 0.7];
end

text(6.65,260,'9 Bar',FontSize=12);
text(7.13,250,'2.6 Bar',FontSize=12);
text(7.65,240,'1 Bar',FontSize=12);
text(8.56,230,'0.1 Bar',FontSize=12);

% Steam seperator 1 -- VAPOR
pls(1) = plotIsobarsTs(9,flow(1).s,flow(2).s);
pls(1).Color = 'r';

% Turbine 1
[plt.Turbine1.T_turbine1,plt.Turbine1.p_turbine1,plt.Turbine1.h_turbine1,plt.Turbine1.s_turbine1,plt.Turbine1.x_turbine1] = turbineProperties(flow(3).p,flow(3).h,eta.is.turbine1,flow(4).p,500);
pls(2) = plot(plt.Turbine1.s_turbine1,plt.Turbine1.T_turbine1);
pls(2).Color = 'r';

% Turbine 2A
[plt.Turbine2A.T_turbine2A,plt.Turbine2A.p_turbine2A,plt.Turbine2A.h_turbine2A,plt.Turbine2A.s_turbine2A,plt.Turbine2A.x_turbine2A] = turbineProperties(flow(12).p,flow(12).h,eta.is.turbine2HPT,flow(29).p,500);
pls(3) = plot(plt.Turbine2A.s_turbine2A,plt.Turbine2A.T_turbine2A);
pls(3).Color = 'r';

% Turbine 2B
[plt.Turbine2B.T_turbine2B,plt.Turbine2B.p_turbine2B,plt.Turbine2B.h_turbine2B,plt.Turbine2B.s_turbine2B,plt.Turbine2B.x_turbine2B] = turbineProperties(flow(30).p,flow(30).h,eta.is.turbine2LPT,flow(15).p,500);
pls(4) = plot(plt.Turbine2B.s_turbine2B,plt.Turbine2B.T_turbine2B);
pls(4).Color = [255 132 0]./255;

% Mixing 18 & 15
pls(5) = plotIsobarsTs(flow(15).p,flow(16).s,flow(15).s);
pls(5).Color = [0 0 1];

% Condenser 1
pls(21) = plotIsobarsTs(flow(4).p,flow(4).s,flow(28).s);
pls(21).Color = [0 185 233]./255;

% Mixing 5' & 16
pls(6) = plotIsobarsTs(flow(16).p,flow(28).s,flow(16).s);
pls(6).Color = [0 185 233]./255;

% Deaerator
pls(7) = plotIsobarsTs(flow(5).p,flow(5).s,flow(6).s);
pls(7).Color = [0 185 233]./255;

% Pump 2
t_67 = linspace(flow(6).t,flow(7).t,500);
s_67 = flow(6).s * ones(1,500);
pls(8) = plot(s_67,t_67);
pls(8).Color = [0 185 233]./255;

% Steam seperator 2
pls(9) = plotIsobarsTs(flow(13).p,flow(13).s,flow(14).s); % VAPOR
pls(9).Color = [255 132 0]./255;
pls(10) = plotIsobarsTs(flow(13).p,flow(19).s,flow(13).s); % LIQUID
pls(10).Color = [255 115 238]./255;

% Steam seperator 1
pls(11) = plotIsobarsTs(flow(1).p,flow(21).s,flow(1).s); % LIQUID
pls(11).Color = [255 115 238]./255;

% Valve 1
pls(12) = plotValve(flow(21).p,flow(21).h,flow(22).p);
pls(12).Color = [255 115 238]./255;

% Valve 2
pls(13) = plotValve(flow(19).p,flow(19).h,flow(20).p);
pls(13).Color = [255 115 238]./255;

% Steam seperator 3
pls(14) = plotIsobarsTs(flow(22).p,flow(22).s,flow(24).s); % VAPOR
pls(14).Color = [0 114 0]./255;
pls(15) = plotIsobarsTs(flow(22).p,flow(23).s,flow(22).s); % LIQUID
pls(15).Color = [255 115 238]./255;

% Steam seperator 3
pls(16) = plotIsobarsTs(flow(20).p,flow(20).s,flow(26).s); % VAPOR
pls(16).Color = [0 114 0]./255;
pls(17) = plotIsobarsTs(flow(20).p,flow(25).s,flow(26).s); % LIQUID
pls(17).Color = [255 115 238]./255;

% Dearator
pls(18) = plotIsobarsTs(flow(11).p, flow(11).s,flow(6).s);
pls(18).Color = 'r';
pls(19) = plotIsobarsTs(flow(5).p, flow(5).s,flow(6).s);
pls(19).Color = [0 185 233]./255;

% Pump 1
t_1718 = linspace(flow(17).t,flow(18).t,500);
s_1718 = flow(17).s * ones(1,500);
pls(20) = plot(s_1718,t_1718);
pls(20).Color = [0 0 1];

% Condeser 2
pls(22) = plotIsobarsTs(flow(16).p,flow(18).s,flow(16).s);
pls(22).Color = [0 0 1];



% Plotting dots at beginning/endpoints of devices   

for i = 1:30
    Xcoordinates(i) = flow(i).s;
    Ycoordinates(i) = flow(i).t;
end

for i = [6:10 27]
    Xcoordinates(i) = NaN;
    Ycoordinates(i) = NaN;
end


pls(19) = plot(Xcoordinates,Ycoordinates,LineStyle='None', Marker='o',MarkerFaceColor='k', MarkerSize=4);


% Numbers at dots

for i=[1 13 19 21 22 25 27]
    text((Xcoordinates(i)),(Ycoordinates(i)),num2str(i), HorizontalAlignment = "right",VerticalAlignment='bottom',FontSize=12)
end
text((Xcoordinates(28)),(Ycoordinates(28)),'5`', HorizontalAlignment = "right",VerticalAlignment='bottom',FontSize=12);
text((Xcoordinates(5)),(Ycoordinates(5)),'5 & 16', HorizontalAlignment = "right",VerticalAlignment='top',FontSize=12);
% text((Xcoordinates(6)),(Ycoordinates(6)),'6 & 7', HorizontalAlignment = "right",VerticalAlignment='top');
text((Xcoordinates(23)),(Ycoordinates(23)),'23 & 25', HorizontalAlignment = "right",VerticalAlignment='bottom',FontSize=12);
text((Xcoordinates(20)),(Ycoordinates(20)),'20', HorizontalAlignment = "center",VerticalAlignment='top',FontSize=12);
text((Xcoordinates(11)+0.12),(Ycoordinates(11)+12),'2 & 3', HorizontalAlignment = "right",VerticalAlignment='bottom',FontSize=12);
text((Xcoordinates(11)+0.20),(Ycoordinates(11)),'11 & 12', HorizontalAlignment = "right",VerticalAlignment='bottom',FontSize=12);
text((Xcoordinates(15)),(Ycoordinates(15)),'15', HorizontalAlignment = "left",VerticalAlignment='bottom',FontSize=12);
text((Xcoordinates(4)-0.1),(Ycoordinates(4)),'4', HorizontalAlignment = "right",VerticalAlignment='bottom',FontSize=12);
text((Xcoordinates(24)),(Ycoordinates(24)),'24 & 26', HorizontalAlignment = "left",VerticalAlignment='bottom',FontSize=12);
text((Xcoordinates(14)),(Ycoordinates(14)),'14', HorizontalAlignment = "left",VerticalAlignment='bottom',FontSize=12);
text((Xcoordinates(29)),(Ycoordinates(29)),'12A', HorizontalAlignment = "right",VerticalAlignment='bottom',FontSize=12);
text((Xcoordinates(30)),(Ycoordinates(30)),'12B', HorizontalAlignment = "left",VerticalAlignment='top',FontSize=12);
text((Xcoordinates(17)),(Ycoordinates(17)),'17 & 18', HorizontalAlignment = "right",VerticalAlignment='bottom',FontSize=12);

% Legend
subset_2 = [
    pl(1)... % Vapor Dome
    pl(2)... % Isobars
    pls(1)... % High P
    pls(9)... % Low P
    pls(12)... % Seperated Fluid
    pls(21)... % Condensed Water
    ];
legend(subset_2,'Vapor Dome', 'Isobars', 'High pressure line', 'Low pressure line', 'Seperated fluid', 'Condensed water');