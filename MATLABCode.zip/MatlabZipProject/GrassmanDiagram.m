clc,clear, close all
% Bram ten Berge, Jasper Koot - December 2024

% Adding the plotflowDiagrams function, made by Jos Havinga.
addpath Functions\plotFlowDiagrams\

% Defining some default settings 
defaultSettings
defaults.out.TextRotation=90;
defaults.blockWidth=60;
defaults.FontSize=12;
defaults.out.FontSize=defaults.FontSize;
defaults.minArrowWidth=0.1;
defaults.norm_fact=3;
defaults.referencePoint='b';
defaults.outputsAlignment='b';
defaults.inputsAlignment='b';
defaults.out.FaceAlpha=0.9;
h=1.7; % These two variables are only made to enlarge all coordinates in x- and y direction to create more space.
p=3;

%% thermal input/block 1
components(1).coordinateX=-100*h;
components(1).coordinateY=0*p;
components(1).drawBlock=false;
components(1).out(1).value=169.6;
components(1).out(1).target=2;
components(1).out(1).type='Thermal Input';
components(1).out(1).flowNumber='1:';

components(14).coordinateX=-100*h;
components(14).coordinateY=169.6*p;
components(14).drawBlock=false;
components(14).out(1).value=26.0;
components(14).out(1).target=2;
components(14).out(1).type='Thermal Input';
components(14).out(1).flowNumber='13:';
components(14).out(1).ShowText=false;



%% steam seperators
components(2).coordinateX=200*h;
components(2).coordinateY=0*p;
components(2).name='Steam seperators';
components(2).in(1).source=1;
components(2).in(2).source=14;
%steam seperator to turbine 1
components(2).out(4).value=71.1;
components(2).out(4).target=3;
components(2).out(4).type='saturated vapor';
components(2).out(4).flowNumber='3:';
%steam seperator to turbine 2
components(2).out(3).value=115.9;
components(2).out(3).target=4;
components(2).out(3).type='saturated vapor';
components(2).out(3).flowNumber='12 & 14:';
%steam seperator loss
components(2).out(1).value=7.8;
components(2).out(1).target=9;
components(2).out(1).type='heat';
components(2).out(1).shape='hvh';
components(2).out(1).verticalLinesX=300*h;
components(2).out(1).textShift=[-40*h -25*p];
components(2).out(1).flowNumber='19 & 21:';
components(2).out(1).ShowText=false;
%to the dearator
components(2).out(2).value=0.9;
components(2).out(2).target=12;
components(2).out(2).type='saturated vapor';
components(2).out(2).shape='hvh';
components(2).out(2).verticalLinesX=975*h;
components(2).out(2).textShift= [-32*h 5*p];
components(2).out(2).flowNumber='11:';
components(2).out(2).ShowText=false;


%% turbine 1
components(3).coordinateX=400*h;
components(3).coordinateY=0*p;
components(3).in(1).source=2;
components(3).name='Turbine 1';
%turbine to generator
components(3).out(2).value=40;
components(3).out(2).target=13;
components(3).out(2).type='work';
%turbine to condenser
components(3).out(1).value=17.1;
components(3).out(1).target=7;
components(3).out(1).type='mixture';
components(3).out(1).shape='hvh';
components(3).out(1).verticalLinesX=670*h;
components(3).out(1).textShift=[-200*h -26*p];
components(3).out(1).FontSize=9;
components(3).out(1).flowNumber='4:';


%% turbine 2
components(4).coordinateX=400*h;
components(4).coordinateY=71.1*p;
components(4).in(1).source=2;
components(4).name='Turbine 2';
%turbine to generator
components(4).out(2).value=60.0;
components(4).out(2).target=13;
components(4).out(2).type='work';
components(4).out(2).shape='hvh';
components(4).out(2).verticalLinesX=570*h;
components(4).out(2).textShift=[10*h 7*p];
%turbine to condenser
components(4).out(1).value=30.1;
components(4).out(1).target=6;
components(4).out(1).type='mixture';
components(4).out(1).shape='hvh';
components(4).out(1).verticalLinesX=580*h;
components(4).out(1).textShift=[-15*h 12.5*p];
components(4).out(1).flowNumber='15:';

%% generators
components(13).coordinateX=750*h;
components(13).coordinateY=0*p;
components(13).in(1).source=4;
components(13).in(2).source=3;
components(13).name='Gens';
%electricity generated
components(13).out(3).value=95;
components(13).out(3).target=8;
components(13).out(3).type='electricity';
components(13).out(3).shape='hvh';
components(13).out(3).verticalLinesX=1000*h;
components(13).out(3).textShift=[-65*h 0*p];
% % thermal power loss
% components(13).out(1).value=3;
% components(13).out(1).target=9;
% components(13).out(1).type='heat';
% components(13).out(1).shape='hvh';
% components(13).out(1).verticalLinesX=880*h;
% components(13).out(1).textShift=[-23*h 680*p];
%to pump 1
components(13).out(1).value=1.7;
components(13).out(1).target=10;
components(13).out(1).type='electricity';
components(13).out(1).shape='hvhvh';
components(13).out(1).verticalLinesX=[800*h 200*h];
components(13).out(1).horizontalLinesY= 250*p;
components(13).out(1).textShift=[0 0*p];
components(13).out(1).ShowText=false;
%to pump 2
components(13).out(2).value=0.3;
components(13).out(2).target=5;
components(13).out(2).type='electricity';
components(13).out(2).shape='hvh';
components(13).out(2).verticalLinesX=1200*h;
components(13).out(2).textShift=[-25*h -17*p];
components(13).out(2).ShowText=false;


%% condenser 1
components(7).coordinateX=750*h;
components(7).coordinateY=(components(3).out(2).value+components(4).out(2).value)*p;
components(7).in(2).source=3;
components(7).in(1).source=11;
components(7).name='C1';
%To cooling tower
components(7).out(1).value=10.4; 
components(7).out(1).target=11;
components(7).out(1).type='compressed liquid';
components(7).out(1).shape='hvhvh';
components(7).out(1).verticalLinesX=[900*h -150*h];
components(7).out(1).horizontalLinesY=-50*p;
components(7).out(1).textShift=[0 22*p];
components(7).out(1).flowNumber='9:';
components(7).out(1).ShowText=false;
%To the dearator
components(7).out(2).value=0.5;
components(7).out(2).target=12;
components(7).out(2).type='saturated liquid';
components(7).out(2).shape='hvh';
components(7).out(2).verticalLinesX=850*h;
components(7).out(2).textShift=[72*h 7.9*p];
components(7).out(2).FontSize=6;
components(7).out(2).flowNumber= '5`:';
components(7).out(2).ShowText=false;



%% condenser 2
components(6).coordinateX=750*h;
components(6).coordinateY=(components(3).out(1).value+components(3).out(2).value+components(4).out(2).value+0.7)*p;
components(6).in(2).source=4;
components(6).in(1).source=10;
components(6).name='C2';
%To the dearrator
components(6).out(1).value=19.3;
components(6).out(1).target=12;
components(6).out(1).type='compressed liquid';
components(6).out(1).shape='hvh';
components(6).out(1).verticalLinesX=950*h;
components(6).out(1).textShift=[-10*h 9*p];
components(6).out(1).flowNumber='16:';



%% total electricity output
components(8).coordinateX=1050*h;
components(8).coordinateY=0*p;
components(8).in(1).source=13;
components(8).name='Electricity output';
components(8).FaceColor=[160 202 83]/255;
components(8).blockWidth=120;
components(8).FontSize=0.0001;



%% total Exergy output rate
components(9).coordinateX=1100*h;
components(9).coordinateY=(300 + (1.2 + 0.7) - (0.1 + 7.8))*p;
components(9).in(1).source=11;
components(9).in(2).source=2;
% components(9).in(3).source=13;
components(9).in(3).source=12;
components(9).name='Exergy to environment 10.6 MW (5.4%)';
components(9).FaceColor=[255 128 128]/255;
components(9).FontSize=0.0001;



%% pump 1
components(10).coordinateX=250*h;
components(10).coordinateY=(300+1.0-2.7)*p;
components(10).in(1).source=11;
components(10).in(2).source=13;
components(10).name='P1';
%to condenser 2
components(10).out(1).value=2.9;
components(10).out(1).target=6;
components(10).out(1).type='compressed liquid';
components(10).out(1).shape='hvh';
components(10).out(1).verticalLinesX=(618)*h;
components(10).out(1).flowNumber='18:';
components(10).out(1).ShowText=false;



%% cooling tower
components(11).coordinateX=0*h;
components(11).coordinateY=300*p;
components(11).in(1).source=5;
components(11).in(2).source=7;
components(11).name='CT';
%to condenser 1
components(11).out(2).value=0.7;
components(11).out(2).target=7;
components(11).out(2).type='compressed liquid';
components(11).out(2).shape='hvh';
components(11).out(2).verticalLinesX=650*h;
components(11).out(2).flowNumber='8:';
components(11).out(2).ShowText=false;
%to pump 1
components(11).out(3).value=1.2;
components(11).out(3).target=10;
components(11).out(3).type='compressed liquid';
components(11).out(3).textShift=[0 -17*p];
components(11).out(3).flowNumber='17:';
components(11).out(3).ShowText=false;
%heat loss
components(11).out(1).value=11.6;
components(11).out(1).target=9;
components(11).out(1).type='heat';
components(11).out(1).textShift=[65*h 17*p];
components(11).out(1).ShowText=false;



%% dearator
components(12).coordinateX=1050*h;
components(12).coordinateY=97*p;
components(12).name='D';
components(12).in(1).source=2;
components(12).in(2).source=6;
components(12).in(3).source=7;
%to pump 2
components(12).out(2).value=17.2;
components(12).out(2).target=5;
components(12).out(2).type='compressed liquid';
components(12).out(2).FontSize=6;
components(12).out(2).textShift=[-24*h 1.5*p];
components(12).out(2).flowNumber='6:';
components(12).out(2).ShowText=false;
%heat loss
components(12).out(1).value=0.1;
components(12).out(1).target=9;
components(12).out(1).type='heat';
components(12).out(1).shape='hvh';
components(12).out(1).verticalLinesX=1075*h;
components(12).out(1).textShift=[-20*h 0];
components(12).out(1).ShowText=false;


%% pump 2
components(5).coordinateX=1250*h;
components(5).coordinateY=96.700*p;
components(5).in(1).source=12;
components(5).in(2).source=13;
components(5).name='P2';
%to the cooling tower
components(5).out(1).value=17.2;
components(5).out(1).target=11;
components(5).out(1).type='compressed liquid';
components(5).out(1).shape='hvhvh';
components(5).out(1).verticalLinesX=[1300*h -150*h];
components(5).out(1).horizontalLinesY=350*p;
components(5).out(1).flowNumber='7:';
components(5).out(1).textShift=[-50*h -4*p];
components(5).out(1).ShowText=false;

defaults.nominalValue=195.6;
plotFlowDiagram

%% Ellipses
for i=1:length(components)
    if isfield(components(i),'out') && ~isempty(components(i).out)
        for j=1:length(components(i).out)
            components(i).out(j).arrowString = {
                [' ' components(i).out(j).flowNumber],...
                ['  ' num2str(round(components(i).out(j).value,defaults.roundDecimals)) ' ' defaults.units],...
                ['(' num2str(round(components(i).out(j).value./defaults.nominalValue.*100,defaults.roundDecimals)) '%)' ]
                };
        end
    end
end

% Thermal input
el(1) = ellipse(90,65,100,-35,90,[0.7 0.5 0.8]);
text(95,-35,components(14).out(1).arrowString,'Rotation',90,'HorizontalAlignment','center',	'FontSize',12)

% Gen to P2
el(4) = ellipse(90,65,1960,195,90,[160 202 83]./255);
text(1950,200,components(13).out(2).arrowString,'Rotation',90,'HorizontalAlignment','center',	'FontSize',12)

% C1 to CT
el(5) = ellipse(90,65,650,-140,90,[65 115 255]./255);
text(640,-140,components(7).out(1).arrowString,'Rotation',90,'HorizontalAlignment','center',	'FontSize',12)

% D to P1
el(6) = ellipse(90,65,1960,400,90,[65 115 255]./255);
text(1950,400,components(12).out(2).arrowString,'Rotation',90,'HorizontalAlignment','center',	'FontSize',12)

% Steam sep to dearator
el(7) = ellipse(90,65,1650,560,90,[230 240 255]/255);
text(1650,560,components(2).out(2).arrowString,'Rotation',90,'HorizontalAlignment','center',	'FontSize',12)

% D to heat loss
el(8) = ellipse(90,65,1830,650,90,[255 128 128]./255);
text(1820,650,components(12).out(1).arrowString,'Rotation',90,'HorizontalAlignment','center',	'FontSize',12)

% Gen to P1
el(9) = ellipse(90,65,820,750,90,[160 202 83]./255);
text(805,750,components(13).out(2).arrowString,'Rotation',90,'HorizontalAlignment','center',	'FontSize',12)

% Steam to loss
el(10) = ellipse(90,65,460,660,90,[255 128 128]./255);
text(460,660,components(2).out(1).arrowString,'Rotation',90,'HorizontalAlignment','center',	'FontSize',12)

% P1 to C2
el(11) = ellipse(90,65,985,655,90,[65 115 255]./255);
text(975,655,components(10).out(1).arrowString,'Rotation',90,'HorizontalAlignment','center',	'FontSize',12)

% CT to C1
el(11) = ellipse(90,65,1160,655,90,[65 115 255]./255);
text(1150,655,components(11).out(2).arrowString,'Rotation',90,'HorizontalAlignment','center',	'FontSize',12)

% CT to P1
el(12) = ellipse(90,65,220,810,90,[65 115 255]./255);
text(210,810,components(11).out(3).arrowString,'Rotation',90,'HorizontalAlignment','center',	'FontSize',12)

% CT to heat loss
el(12) = ellipse(90,65,1250,1020,90,[255 128 128]./255);
text(1240,1020,components(11).out(1).arrowString,'Rotation',90,'HorizontalAlignment','center',	'FontSize',12)

% P2 to CT
el(13) = ellipse(90,65,880,1080,90,[65 115 255]./255);
text(870,1080,components(5).out(1).arrowString,'Rotation',90,'HorizontalAlignment','center',	'FontSize',12)

% C1 to Dearator
el(14) = ellipse(80,58,1470,374,90,[115 171 255]./255);
text(1465,374,components(7).out(2).arrowString,'Rotation',90,'HorizontalAlignment','center',	'FontSize',12)

% T1 to C1
el(15) = ellipse(80,58,790,150,90,[172 206 255]./255);
text(790,150,components(3).out(1).arrowString,'Rotation',90,'HorizontalAlignment','center',	'FontSize',12)

% Text for elec output 
text(1764,150,'Net electricity output','Rotation',90,'HorizontalAlignment','center',	'FontSize',12)
text(1796,150, '95 MW (48.6%)','Rotation',90,'HorizontalAlignment','center',	'FontSize',12)

% Exergy output
el(15) = ellipse(120,87,1920,905,90,[255 128 128]./255);
text(1890,910,'Thermal exergy','Rotation',90,'HorizontalAlignment','center',	'FontSize',12)
text(1913,910,'rate output','Rotation',90,'HorizontalAlignment','center',	'FontSize',12)
text(1940,910,'19.5MW (10.0%)','Rotation',90,'HorizontalAlignment','center',	'FontSize',12)


%% Legend
subset = [
    components(1).out(1).arrowHandle, ...
    components(2).out(1).arrowHandle, ...
    components(2).out(2).arrowHandle, ...
    components(4).out(1).arrowHandle, ...
    components(7).out(2).arrowHandle, ...
    components(5).out(1).arrowHandle, ...
    components(4).out(2).arrowHandle, ...
    components(13).out(2).arrowHandle ...
    ];

% legend(subset,'Thermal Input','Heat','Saturated Vapor','Mixture','Saturated Liquid','Compressed Liquid','Work','Electricity','Orientation','horizontal')

% Reference State
text(2325,900,['T_0 = 15' char(176) 'C, P_0 = 1 bar'],'Rotation',90,'HorizontalAlignment','center',	'FontSize',20)

% plotDebugGrid