function [Valve] = plotValve(p_in,h_in,p_out)
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here

Pressure = linspace(p_in,p_out,501);
s = NaN(1,length(Pressure));
T = NaN(1,length(Pressure));

for i=1:length(Pressure)
    s(i) = XSteam('s_ph',Pressure(i),h_in);
    T(i) = XSteam('t_ph',Pressure(i),h_in);
end
Valve = plot(s,T);
hold on

end