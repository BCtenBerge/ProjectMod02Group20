% This file is part of the +radicalroots library
%
% This Source Code Form is subject to the terms of the Mozilla Public
% License, v. 2.0. If a copy of the MPL was not distributed with this
% file, You can obtain one at http://mozilla.org/MPL/2.0/.
%
% (C) Niels ter Meer

function y = polyval(f, x)
arguments
	f (1, :) cell
	x double
end
	% A parallel implementation of Horner's method to evaluate polynomials

	y = f{1};

	for idx = 2:length(f)
		y = f{idx} + x.*y;
	end
end
