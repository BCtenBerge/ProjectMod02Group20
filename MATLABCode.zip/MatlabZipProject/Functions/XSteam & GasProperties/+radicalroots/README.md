# Radicalroots: Solve polynomials up to degree 4 (or more)

Polynomials of up to degree 4 can be solved using radicals. Even though Matlab has
facilities in place to solve _any_ polynomial (see `roots`), it can't do this vectorised;
it has to do this for each polynomial separately. Using the radicals approach allows the
solution to be found for many sets of polynomials at the same time.

It is based on the work of David J. Wolters, at
[quarticequations.com](https://quarticequations.com/).

When degree 4 does not suffice, or some margin is tolerated, parallel versions of
`polydiff`, `polyint`, `polyval` are provided, along with a parallel implementations of
Newton's method.

The name is a play on being able to use radicals to find the roots of polynomials, but
also on the radically different approach this package takes.

## Installation
Place the contents of this repository in a directory called `+radicalroots`. The
directory should be placed somewhere in Matlab's search path.

## Licence
This work by Niels ter Meer is licensed to you under the Mozilla Public License, version
2. You can the licence in the [LICENCE](LICENCE) file in this project's source tree root
folder.
