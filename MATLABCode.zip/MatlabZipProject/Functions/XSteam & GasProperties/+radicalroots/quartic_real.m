% This file is part of the +radicalroots library
%
% This Source Code Form is subject to the terms of the Mozilla Public
% License, v. 2.0. If a copy of the MPL was not distributed with this
% file, You can obtain one at http://mozilla.org/MPL/2.0/.
%
% (C) Niels ter Meer

% Find the smallest postive real root of a quartic equation, if there is one.
function [z1, z2] = quartic_real(c4, c3, c2, c1, c0, kwargs)
arguments
	c4
	c3
	c2
	c1
	c0

	kwargs.throw_ifnot_positive = false;
end
	[mh, mh_b2h, R, c] = radicalroots.quartic_core(c4, c3, c2, c1, c0);

	% There is only one term in this algorithm which can cause roots to be complex,
	% namely the √(-m/2 - b₂/2 ± R). If this is negative, it causes its corresponding
	% root group to be complex. Hence we first look whether adding or substracting R
	% makes a root group complex.

	D1 = sign(-mh_b2h + R);
	D1_check = sign(-mh_b2h - R);

	% If both adding and substracting have
	if any(D1 == D1_check & ~isnan(D1), 'all')

		if any(D1 == -1, 'all')
			throw(MException('radicalroots:quartic_real:no_real_solutions', ...
				'Some polynomials given have no real solution' ...
			));
		elseif any(D1 == 1, 'all')
			throw(MException('radicalroots:quartic_real:four_real_solutions', ...
				'Some polynomials given have four real solutions; not supported atm' ...
			));
		end
	end

	% At this point we know we only have one root-group with real roots. The D1
	% discriminator discriminates between the z12 and z34 groups. Now we can define
	% the a and b terms of the root pair (we already have c)
	a = sqrt(-mh_b2h + D1.*R);
	b = D1.*sqrt(mh);

	groupcenter = -c - b;

	% If D2 is negative, that implies that the group - a root lies below zero, and
	% thus the smallest positive real root.
	D2 = sign(groupcenter - a);
	% To get that root, we then here basically do minus-minus to make a plus. This
	% guarantees that, if there is a positive real root, z1 will be the smallest.
	z1 = groupcenter - D2.*a;
	z2 = groupcenter + D2.*a;

	% However, it may be the case that z1 does still turn out to be negative (but
	% just less negative than z2), for which this block explicitly checks if
	% required.
	if kwargs.throw_ifnot_positive && any(z1 < 0)
		throw(MException('radicalroots:quartic_real:no_positive_solution', ...
			'Some polynomial has no positive solution'))
	end
end
