% This file is part of the +radicalroots library
%
% This Source Code Form is subject to the terms of the Mozilla Public
% License, v. 2.0. If a copy of the MPL was not distributed with this
% file, You can obtain one at http://mozilla.org/MPL/2.0/.
%
% (C) Niels ter Meer

% Solve for the roots of the quadratic equation given by:
%   z² + a₁z + a₀ = 0
%
% Note that any equation of the form:
%   c₂z² + c₁z + c₀ = 0
% can be reduced to that form by dividing c₁ through c₀ by c₂ to yield a₁ through a₀
%
% The roots are returned such that z1 >= z2. The discriminant is returned in the third
% slot
function [z1, z2, D] = quadratic(c2, c1, c0)
	a1 = c1./c2;
	a0 = c0./c2;

	D  = a1.^2 - 4.*a0;
	sD = sqrt(D);
	z1 = (-a1 + sD)./2;
	z2 = (-a1 - sD)./2;
end
