% This file is part of the +radicalroots library
%
% This Source Code Form is subject to the terms of the Mozilla Public
% License, v. 2.0. If a copy of the MPL was not distributed with this
% file, You can obtain one at http://mozilla.org/MPL/2.0/.
%
% (C) Niels ter Meer

% Solve for the roots of the quartic equation given by:
%   c₄z⁴ + c₃z³ + c₂ z² + c₁z + c₀ = 0
%
% The roots are returned in no particular order.
function [z1, z2, z3, z4] = quartic(c4, c3, c2, c1, c0)
	[mh, mhb2h, R, C] = radicalroots.quartic_core(c4, c3, c2, c1, c0);
	minus = -mhb2h - R;
	plus  = -mhb2h + R;

	midpoint  = -C;
	leftpair  = midpoint - smh;
	rightpair = midpoint + smh;

	R2minus = sqrt(minus);
	R2plus  = sqrt(plus);

	z1 = rightpair - R2minus;
	z2 = rightpair + R2minus;
	z3 = leftpair  - R2plus;
	z4 = leftpair  + R2plus;
end
