% This file is part of the +radicalroots library
%
% This Source Code Form is subject to the terms of the Mozilla Public
% License, v. 2.0. If a copy of the MPL was not distributed with this
% file, You can obtain one at http://mozilla.org/MPL/2.0/.
%
% (C) Niels ter Meer

function [x, fval, iters, converged] = ppolysolve(p, x0, varargin)
	dp = radicalroots.polydiff(p);

	 f = @(x) radicalroots.polyval( p, x);
	df = @(x) radicalroots.polyval(dp, x);

	[x, fval, iters, converged] = radicalroots.newton(f, df, x0, varargin{:});
end
