% This file is part of the +radicalroots library
%
% This Source Code Form is subject to the terms of the Mozilla Public
% License, v. 2.0. If a copy of the MPL was not distributed with this
% file, You can obtain one at http://mozilla.org/MPL/2.0/.
%
% (C) Niels ter Meer

% Solve for the roots of the linear equation given by:
%   z + a₀ = 0
%
% Note that any equation of the form:
%   c₁z + c₀ = 0
% can be reduced to that form by dividing c₀ by c₁ to yield a₀
function z1 = linear(c1, c0)
	a0 = c0./c1;
	z1 = -a0;
end
