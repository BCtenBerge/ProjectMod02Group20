% This file is part of the +radicalroots library
%
% This Source Code Form is subject to the terms of the Mozilla Public
% License, v. 2.0. If a copy of the MPL was not distributed with this
% file, You can obtain one at http://mozilla.org/MPL/2.0/.
%
% (C) Niels ter Meer

function [x, fval, iters, converged] = newton(f, df, x0, kwargs)
arguments
	f
	df
	x0
	kwargs.precycles = 2
	kwargs.tol = 1e-6
	kwargs.dbg = false
	kwargs.maxiters = 20
	kwargs.panic_on_dfzero = eps;
	kwargs.debug = false;
	kwargs.validate = @(x) true;
end

	switch numel(x0)
	case 1
		x = x0;
		lowerb = -inf;
		upperb = inf;
	case 2
		x0 = sort(x0);
		x = mean(x0);
		lowerb = x0(1);
		upperb = x0(2);
	case 3
		x0 = sort(x0);
		lowerb = x0(1);
		x = x0(2);
		upperb = x0(3);
	otherwise
		throw(MException('radicalroots:newton:bad_x0', 'Bad x0'));
	end

	fval = f(x);
	iters = 0;

	dbg = @(iter, fvals) kwargs.debug && fprintf('%3i %f %f %f\n', iter, min(fvals, [], 'all'), mean(fvals, 'all'), max(fvals, [], 'all'));

	while iters < kwargs.maxiters && ~all(abs(fval) < kwargs.tol, 'all')
		dbg(iters, fval);
		d = df(x);

		if kwargs.panic_on_dfzero > 0 && any(abs(d) < kwargs.panic_on_dfzero, 'all')
			throw(MException('radicalroots:newton:dfzero', 'Hit zero derivative point'))
		end
		x = clamp(x - fval./d, lowerb, upperb);

		if ~kwargs.validate(x)
			throw(MException('radicalroots:newton:validation_failure', 'validation failure'))
		end
		fval = f(x);
		iters = iters + 1;
	end

	if nargout == 4
		converged = all(abs(fval) < kwargs.tol, 'all');
	end
	dbg(iters, fval);

	% TODO: The current implementation keeps iterating until _all_ equations have
	% converged. Perhaps we can be smarter; only iterating further on those that have
	% not converged yet (if this works out from a performance perspective).
end

function x = clamp(x, a, b)
	x(x < a) = a;
	x(x > b) = b;
end
