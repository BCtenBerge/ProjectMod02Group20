% This file is part of the +radicalroots library
%
% This Source Code Form is subject to the terms of the Mozilla Public
% License, v. 2.0. If a copy of the MPL was not distributed with this
% file, You can obtain one at http://mozilla.org/MPL/2.0/.
%
% (C) Niels ter Meer

% Solve for the roots of the cubic equation given by:
%   c₃z³ + c₂ z² + c₁z + c₀ = 0
%
% The roots are returned as follows:
%    | complex  | all-real
%    | D > 0    | D <= 0
% z1 | real     | greatest
% z2 | complex+ | middle
% z3 | complex- | lowest
% Where D is the discriminant r^2 + q^3.
%
% In other words, if the solution is complex, the real root is returned as z1, while z2
% and z3 are the remaining two complex roots. If the solution is all-real, z1 is the
% greatest solution, such that z1 >= z2 >= z1.
%
% If one or two return values are requested, only root z1 is computed, and the
% discriminant D is returned in the second slot.
% If three or more return values are requested, all roots are computed, and the
% discriminant D is returned as the fourth return value.
function varargout = cubic(c3, c2, c1, c0)
	a2 = c2./c3;
	a1 = c1./c3;
	a0 = c0./c3;

	q = a1./3 - a2.^2./9;
	r = (a1.*a2 - 3.*a0)./6 - a2.^3./27;

	D = r.^2 + q.^3;
	Dc = D > 0;

	% "Broadcast" A2 into a shape which is compatible with D, so that the appropriate
	% values can be selected out of it with D > 0 to forward to each sub-solution
	A2 = a2 + 0.*a1 + 0.*a0;
	assert(all(size(A2) == size(D)));

	% The computation of D "mixes" a2, a1, and a0 such that its size is the same as
	% the expected output size
	z1 = nan(size(D));
	if nargout <= 2
		z1(Dc) = one_real_all_roots(r(Dc), q(Dc), A2(Dc), D(Dc));
		z1(~Dc) = viete(r(~Dc), q(~Dc), A2(~Dc));

		assert(all(size(z1) == size(D)));

		varargout{1} = z1;
		varargout{2} = D;
	else
		z2 = nan(size(D));
		z3 = nan(size(D));
		[z1(Dc), z2(Dc), z3(Dc)] = one_real_all_roots(r(Dc), q(Dc), A2(Dc), D(Dc));
		[z1(~Dc), z2(~Dc), z3(~Dc)] = viete(r(~Dc), q(~Dc), A2(~Dc));

		assert(all(size(z2) == size(D)));
		assert(all(size(z3) == size(D)));

		varargout{1} = z1;
		varargout{2} = z2;
		varargout{3} = z3;
		varargout{4} = D;
	end
end

% One real root and two complex roots. z1 is the real root.
function [z1, z2, z3] = one_real_all_roots(r, q, a2, D);
	A = nthroot(abs(r) + sqrt(D), 3);

	% TODO: is there a better way of doing this?
	t1 = A - q./A;
	t1(r<0) = -t1(r<0);

	z1 = t1 - a2./3;

	if nargout > 1
		z2 = -t1./2 - a2./3 + 1i.*sqrt(3)/2.*(A + q./A);
		z3 = conj(z2);
	end
end

% Three real roots, z3 <= z2 <= z1
function [z1, z2, z3] = viete(r, q, a2)

	theta = zeros(size(q));
	theta(q<0) = acos(r(q<0)./(-q(q < 0)).^(3/2));

	assert(all(theta >= 0 & theta <= pi, 'all'))

	phi1 = theta./3;
	phi2 = phi1 - 2.*pi./3;
	phi3 = phi1 + 2.*pi./3;

	a23 = a2./3;
	sqq2 = 2.*sqrt(-q);
	z1 = sqq2.*cos(phi1) - a23;

	if nargout > 1
		z2 = sqq2.*cos(phi2) - a23;
		z3 = sqq2.*cos(phi3) - a23;
	end
end
