% This file is part of the +radicalroots library
%
% This Source Code Form is subject to the terms of the Mozilla Public
% License, v. 2.0. If a copy of the MPL was not distributed with this
% file, You can obtain one at http://mozilla.org/MPL/2.0/.
%
% (C) Niels ter Meer

% Private function
%
% Does the core computations for the quartic* functions, which they then use to
% generate the roots based on their particular guarantees.
function [mh, mhb2h, R, C] = quartic_core(c4, c3, c2, c1, c0)
	a3 = c3./c4;
	a2 = c2./c4;
	a1 = c1./c4;
	a0 = c0./c4;

	C = a3./4;
	b2 = a2 - 6.*C.^2;
	b1 = a1 - 2.*a2.*C + 8.*C.^3;
	b0 = a0 - a1.*C + a2.*C.^2 - 3.*C.^4;

	m1 = radicalroots.cubic(1, b2, b2.^2./4 - b0, -b1.^2./8);
	m = max(m1, 0);

	sigma = sign(b1);

	R = sigma.*nthroot(m.^2 + b2.*m + b2.^2./4 - b0, 2);

	mh = m./2;
	b2h = b2./2;

	smh = nthroot(mh, 2);

	mhb2h = mh + b2h;
end
