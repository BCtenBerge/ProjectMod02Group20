% This file is part of the +radicalroots library
%
% This Source Code Form is subject to the terms of the Mozilla Public
% License, v. 2.0. If a copy of the MPL was not distributed with this
% file, You can obtain one at http://mozilla.org/MPL/2.0/.
%
% (C) Niels ter Meer

function varargout = polydiff(p, k)
arguments
	p (1, :) cell
	k.n = 1;
end

	d = do_diff(p, k.n);

	if nargout == 1 || nargout == 0
		varargout{1} = d;
	elseif nargout == numel(d)
		varargout = d;
	else
		throw(MException('radicalroots:polydiff:lenmismatch'))
	end
end

function d = do_diff(f, n)
	assert(isrow(f) || iscolumn(f));
	N = numel(f);
	M = N - n;

	d = cell(1, M);

	for idx = 1:M
		power = N - idx;
		const = factorial(power)./factorial(power - n);
		d{idx} = const.*f{idx};
	end
end
