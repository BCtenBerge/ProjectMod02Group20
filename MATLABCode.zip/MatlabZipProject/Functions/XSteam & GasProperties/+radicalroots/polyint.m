% This file is part of the +radicalroots library
%
% This Source Code Form is subject to the terms of the Mozilla Public
% License, v. 2.0. If a copy of the MPL was not distributed with this
% file, You can obtain one at http://mozilla.org/MPL/2.0/.
%
% (C) Niels ter Meer

function I = polyint(p, k)
arguments
	p
	k.c = 0
end
	M = numel(p) + 1;
	I = cell(1, M);

	for idx = 1:(M -1)
		idx;
		power = M - idx;
		I{idx} = p{idx}./power;
	end

	I{end} = k.c;
end
