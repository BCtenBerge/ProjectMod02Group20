% This file is part of the +gasprops library
%
% This Source Code Form is subject to the terms of the Mozilla Public
% License, v. 2.0. If a copy of the MPL was not distributed with this
% file, You can obtain one at http://mozilla.org/MPL/2.0/.
%
% (C) Niels ter Meer

% Solve polynomials with the Newton-Rhapson method.
classdef newton < gasprops.solver.abc

properties
	solver_kwargs = {}
end

methods
	function this = newton(varargin)
		this.solver_kwargs = varargin;
	end

	function compatible_with(this, gas)
		% compatible with any reasonably smooth polynomial gas model, only I
		% haven't come up with any metric to check reasonables
	end

	function T2 = T2_T1dh(this, gas, T1, dh)
		T2 = this.T2_T1dx(gas.f, T1, dh, gas.trange);
	end

	function T2 = T2_T1du(this, gas, T1, du)
		T2 = this.T2_T1dx(gas.f_cv, T1, du, gas.trange);
	end

	function T2 = T2_T1dx(this, f, T1, dx, trange)
		c = arr2cellpoly(f);

		F = radicalroots.polyint(c);
		e = F{end} - radicalroots.polyval(F, T1) - dx;

		T2 = radicalroots.ppolysolve({F{1:(end-1)}, e}, trange, this.solver_kwargs{:});
	end

	function T2 = T2_T1dsr(this, gas, T1, ds, r)
		c = arr2cellpoly(gas.f);

		f = c(1:end-1);
		F = radicalroots.polyint(f);
		c0 = c{end};

		 I = @(x) radicalroots.polyval(F, x) + c0.*log(x);
		dI = @(x) radicalroots.polyval(f, x) + c0./x;

		constant = -I(T1) - ds - gas.R.*log(r);

		Iaug = @(x) I(x) + constant;

		T2 = radicalroots.newton(Iaug, dI, gas.trange, this.solver_kwargs{:});
	end
end
end

function c = arr2cellpoly(a)
	c = mat2cell(a, 1, ones(1, size(a, 2)));
end
