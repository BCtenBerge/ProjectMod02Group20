% This file is part of the +gasprops library
%
% This Source Code Form is subject to the terms of the Mozilla Public
% License, v. 2.0. If a copy of the MPL was not distributed with this
% file, You can obtain one at http://mozilla.org/MPL/2.0/.
%
% (C) Niels ter Meer

% Algebraic solver for the case of C_p(T) = const
classdef algebraic1 < gasprops.solver.abc

methods
	function compatible_with(this, gas)
		if numel(gas.f) ~= 1
			error('gasprops:solver:algebraic1:not_compatible_with_gas', ...
				'The gas polynomial is not compatible with this solver');
		end
	end

	function T2 = T2_T1dh(this, gas, T1, dh)
		cp = gas.f;
		T = dh./cp + T1;
	end

	function T2 = T2_T1du(this, gas, T1, du)
		cv = gas.f - gas.R;
		T = du./cv + T1;
	end

	function T2 = T2_T1dsr(this, gas, T1, ds, r)
		cp = gas.f;
		T2 = T1.*exp((ds + gas.R.*log(r))./cp)
	end
end
end
