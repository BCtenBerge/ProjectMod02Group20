% This file is part of the +gasprops library
%
% This Source Code Form is subject to the terms of the Mozilla Public
% License, v. 2.0. If a copy of the MPL was not distributed with this
% file, You can obtain one at http://mozilla.org/MPL/2.0/.
%
% (C) Niels ter Meer

% Solve fourth order Cp polynomials
classdef algebraic4 < gasprops.solver.abc

properties(Constant)
	msg = 'Failed to solve for T_2. This may be caused by bad inputs, a malformed polynomial, or a bug in the solver. Please email n.termeer@student.utwente.nl'
end

methods
	function compatible_with(this, gas)
		if numel(gas.f) ~= 4
			error('gasprops:solver:algebraic4:not_compatible_with_gas', ...
				'The gas polynomial is not compatible with this solver');
		end
	end

	function T2 = T2_T1dh(this, gas, T1, dh)
		T2 = this.T2_T1dx(gas.f, T1, dh);
	end

	function T2 = T2_T1du(this, gas, T1, du)
		T2 = this.T2_T1dx(gas.f_cv, T1, du);
	end

	function T2 = T2_T1dx(this, f, T1, dx)
		assert(numel(f) == 4);
		F = polyint(f, 0);
		e = F(end) - polyval(F, T1) - dx;

		% The polynomials we work with here should have two real solutions, which
		% this finds. Using this over radicalroots.quartic since the root we need
		% might be any of the four that returns. radicalroots.quartic_real gives
		% a bit more guarantees on the root(s) it returns, namely that the
		% smallest positive real root is the first one returned.
		%
		% The try-catch block is therefore a hedge. Just in case there is a bug
		% somewhere in the solver or the polynomials, at least we'll know.
		try
			T2 = radicalroots.quartic_real(F(1), F(2), F(3), F(4), e, ...
				throw_ifnot_positive=true);
		catch e
			new_e = MException('gasprops:solver:algebraic4:bad_poly:T2_T1dh', ...
				this.msg);

			new_e = addCause(new_e, e);

			throw(new_e);
		end
	end

	function T2 = T2_T1dsr(this, gas, T1, ds, r)
		assert(numel(gas.f) == 4);
		% The equation describing the entropy is:
		%              T₂
		%    s₂ - s₁ = ∫ Cp(T)/T dT - R ln(P₂/P₁)
		%              T₁
		% in which we want to solve for T₂. Working out the integration shows
		% that:
		%                               T₂
		%    s₂ - s₁ = [∑cᵢTⁱ + c₀ ln(T)]   - R ln(P₂/P₁)
		%                               T₁
		% i.e., we have another polynomial, plus another log factor.
		F = polyint(gas.f(1:end-1));
		c0 = gas.f(end);

		% This is not a polynomial that can be solved algebraically.
		%
		% But it can be solved if one approximates ln(T) with a Taylor series.
		% If one naively implements the logarithmic part of that integral as:
		%    ln(T₂) - ln(T₁)
		% then one of them will always be far away from the centre point of the
		% approximation, thus becoming less precise. But, by logarithmic
		% identities it becomes:
		%    ln(T₂) - ln(T₁) = ln(T₂/T₁)
		% Let x = T₂/T₁. The Taylor series expansion around ξ then is:
		%             n
		%    ln(x) ≅  ∑[(x - ξ)ⁱ/(i ξⁱ)] + log(ξ)
		%            i=1
		% which can be simplified to:
		%             n
		%    ln(x) ≅  ∑[tᵢ xⁱ] + log(ξ) + t₀
		%            i=1
		% where tᵢ ∝ 1/(T₁ξ)ⁱ. The derivation of the actual values of tᵢ were
		% performed with the matlab symbolic toolbox.
		%
		% But this still leaves the question of what to pick for ξ; the midpoint
		% of the Taylor series. As alluded to earlier, we would want ξ ≅ T₂/T₁ to
		% keep the Taylor series' truncation error manageable. This can't be done
		% by just hardcoding in a value. However, by assuming that Cp₀ = Cp(T₁),
		% we have that:
		%    T₂/T₁ ≅ exp((R log(P₂/P₁) + s₂ - s₁)/Cp₀)
		% and thus a good value for the midpoint ξ. As an added bonus, when
		% s₂ - s₁ = 0 and P₂/P₁ = 0, the centerpoint ξ will also be 1, ensuring
		% that T₂ = T₁.
		Cp0 = gas.cp(T1);
		Rr = gas.R.*log(r);
		xi = exp((Rr + ds)./Cp0);

		% Substituting x = T₂/T₁ back into the Taylor series expanison yields:
		%                 n
		%    ln(T₂/T₁) ≅  ∑[tᵢ (T₂/T₁)ⁱ] + ln(ξ) + t₀
		%                i=1
		% This can be rearranged to:
		%                 n
		%    ln(T₂/T₁) ≅  ∑[T₂ⁱ (tᵢ/T₁ⁱ)] + ln(ξ) + t₀
		%                i=1
		% Given that T₁ is a known value, it can just be folded into the
		% constant!
		%
		% The entropy change equation above then becomes (omitting the summation
		% sub/superscripts from i = 1 to n):
		%    s₂ - s₁ = ∑cᵢT₂ⁱ - ∑cᵢT₁ⁱ
		%            + c₀ { ∑[T₂ⁱ (tᵢ/T₁ⁱ)] + log(ξ) + t₀ }
		%            - R ln(P₂/P₁)
		% Which can be rearranged to (with variable name annotations):
		%          ( g3, g2, & g1  )
		%    ∑[T₂ⁱ (cᵢ + c₀(tᵢ/T₁ⁱ))]
		%         - ∑cᵢT₁ⁱ                  p    ⎫
		%         + c₀ (log(ξ) + t₀)        c0lx ⎬ constant_term
		%         - R ln(P₂/P₁)             Rr   ⎪
		%         - s₂ - s₁                 ds   ⎭
		%      = 0
		% which is a polynomial as a function of T₂, which can be solved for its
		% roots.
		%
		% Which only leaves the question of what order Taylor series to pick. For
		% an algebraic solver, n is already limited to 4, given that 5th order
		% polynomials are not solvable with radicals (which is the whole point of
		% this implementation). For a third order description of Cp, the
		% ∫ Cp(T)/T dT term is also a third order polynomial. To limit the
		% computational requirements, choosing a third order expansion for ln(x)
		% is natural, which is what this implementation does.
		%
		% However, when T₂/T₁ - ξ grows, so does the truncation error of the
		% Taylor series. This can happen, for example, because T₁ is set to the
		% bottom end of the valid range, and thus Cp(T₁) = Cp₀ might no longer be
		% a good approximation. To manage this error, an additional term can be
		% added to the Taylor series, which is what is done in `algebraic4ext`.

		c0lx = c0.*(log(xi) - 11/6);

		p = -polyval(F, T1);
		constant_term = p + c0lx - Rr - ds;

		T1xi = T1.*xi;
		g3 = F(1) + c0./(3.*T1xi.^3);
		g2 = F(2) - 3.*c0./(2.*T1xi.^2);
		g1 = F(3) + 3.*c0./T1xi;
		g0 = constant_term;

		try
			T2 = radicalroots.cubic(g3, g2, g1, g0);
		catch e
			new_e = MException('gasprops:solver:algebraic4:bad_poly:T2_T1dsr', ...
				this.msg);

			new_e = addCause(new_e, e);

			throw(new_e);
		end
	end
end
end
