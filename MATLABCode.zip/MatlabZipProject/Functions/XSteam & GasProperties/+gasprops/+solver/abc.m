% This file is part of the +gasprops library
%
% This Source Code Form is subject to the terms of the Mozilla Public
% License, v. 2.0. If a copy of the MPL was not distributed with this
% file, You can obtain one at http://mozilla.org/MPL/2.0/.
%
% (C) Niels ter Meer

% Abstract base class for the nonlinear temperature solvers.
%
% An abstract base class defines shared behaviour for its descendant classes, but since
% it's abstract it cannot be instansiated itself. This is useful for typechecking
% purposes; people can't substitute a double for a `gasprops.solver.abc`
classdef abc

methods(Abstract)
	% Is called in the `gasprops.gas` solver and is passed in the gas definition, to
	% check whether the solver is compatible with that particular gas. This should
	% throw an error if it is not.
	compatible_with(this, gas);

	T = T2_T1dh(this, gas, T1, dh);
	T = T2_T1du(this, gas, T1, du);
	T = T2_T1dsr(this, gas, T1, ds, r);
end

end
