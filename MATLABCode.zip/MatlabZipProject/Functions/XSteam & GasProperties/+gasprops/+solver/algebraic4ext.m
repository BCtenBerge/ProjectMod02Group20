% This file is part of the +gasprops library
%
% This Source Code Form is subject to the terms of the Mozilla Public
% License, v. 2.0. If a copy of the MPL was not distributed with this
% file, You can obtain one at http://mozilla.org/MPL/2.0/.
%
% (C) Niels ter Meer

% Extend the algebraic4 solver to use a higher order Taylor series approximation of the
% logarithm
classdef algebraic4ext < gasprops.solver.algebraic4

methods
	function T2 = T2_T1dsr(this, gas, T1, ds, r)
		assert(numel(gas.f) == 4);
		% As described in `algebraic4`, we solve for T₂ with polynomial solvers
		% by approximating the ln(T) term with a Taylor series. `algebraic4` does
		% this with a third order Taylor series, but this implementation does it
		% with a fourth order Taylor series, to keep the truncation error when
		% T₂/T₁ grows in check.
		%
		% If you're wondering about the derivation of this math, review the
		% comment in `algebraic4`.

		Cp0 = gas.cp(T1);
		Rr = gas.R.*log(r);
		xi = exp((Rr + ds)./Cp0);

		F = polyint(gas.f(1:end-1));
		c0 = gas.f(end);

		c0lx = c0.*(log(xi) - 25/12);

		p = -polyval(F, T1);
		constant_term = p + c0lx - Rr - ds;

		T1xi = T1.*xi;
		g4 =      -  3.*c0./(12.*T1xi.^4);
		g3 = F(1) + 16.*c0./(12.*T1xi.^3);
		g2 = F(2) - 36.*c0./(12.*T1xi.^2);
		g1 = F(3) + 48.*c0./(12.*T1xi.^1);
		g0 = constant_term;

		try
			T2 = radicalroots.quartic_real(g4, g3, g2, g1, g0);
		catch e
			new_e = MException('gasprops:solver:algebraic4ext:bad_poly:T2_T1dsr', ...
				this.msg);

			new_e = addCause(new_e, e);

			throw(new_e);
		end
	end
end
end
