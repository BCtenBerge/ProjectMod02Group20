% This file is part of the +gasprops library
%
% This Source Code Form is subject to the terms of the Mozilla Public
% License, v. 2.0. If a copy of the MPL was not distributed with this
% file, You can obtain one at http://mozilla.org/MPL/2.0/.
%
% (C) Niels ter Meer

% The numerical data has been taken from "Thermodynamics: An Engineering Approach" by
% Yunus A. Çengel et al., 8th edition, table A–17 (SI). Original source of Data: Kenneth
% Wark, Thermodynamics, 4th ed. (New York: McGraw-Hill, 1983), pp. 785–86, table A–5.
% Originally published in J. H. Keenan and J. Kaye, Gas Tables (New York: John Wiley &
% Sons, 1948).
classdef airbook

methods(Static)
	function [vals, tbl] = table_values()
		vals = sortrows([
			gasprops.airbook.permute_book_into_array(gasprops.airbook.book_regular_5, 5)
			gasprops.airbook.permute_book_into_array(gasprops.airbook.straggling_four, 4)
			gasprops.airbook.permute_book_into_array(gasprops.airbook.straggling_three, 3)
			gasprops.airbook.permute_book_into_array(gasprops.airbook.straggling_twos, 2)
		]);

		if nargout == 2
			T  = vals(:, 1);
			h  = vals(:, 2);
			Pr = vals(:, 3);
			u  = vals(:, 4);
			vr = vals(:, 5);
			sT = vals(:, 6);
			tbl = table(T, h, Pr, u, vr, sT);
		end
	end

	function block = permute_book_into_array(val, blocksize)
		block = reshape(val, blocksize, 6, []);
		block = permute(block, [1 3 2]);
		block = reshape(block, [], 6);
	end

	function obj = pressure_bar()
		obj = gasprops.airbook(ref=gasprops.refstate(0, 1, 0, 0));
	end
end

methods
	function this = airbook(kwargs)
	arguments
		kwargs.gif = @(x, y) griddedInterpolant(x, y)
		kwargs.ref (1, 1) = gasprops.refstate(0, 100, 0, 0),
	end
		this.ref = kwargs.ref;
a
		z = gasprops.airbook.table_values();

		this.i_h_T =  kwargs.gif(z(:, 1), z(:, 2));
		this.i_T_h =  kwargs.gif(z(:, 2), z(:, 1));
		this.i_sT_T = kwargs.gif(z(:, 1), z(:, 6));
		this.i_T_sT = kwargs.gif(z(:, 6), z(:, 1));

		[Tmin, Tmax] = bounds(z(:, 1));
		this.trange = [Tmin, Tmax];
	end

	% Construct a new gasmodel with h0 at a specific temperature other than 0 K
	function other = h0_at_T(this, T)
		r = this.ref;
		other = gasprops.airbook(ref = gasprops.refstate(T, r.P0, -this.i_h_T(T), r.s0));
	end

	function other = state0_at_T(this, T)
		r = this.ref;
		other = gasprops.airbook(ref = gasprops.refstate(T, r.P0, -this.i_h_T(T), 0));
	end
end

properties(SetAccess = protected)
	ref
	trange
end

properties(Access = protected)
	% Interpolation tables.
	i_T_h
	i_h_T
	i_sT_T	% Temperature dependent part of entropy
	i_T_sT
end

methods

	function cp = cp(this, T)
		dT = 1e-6;
		cp = (this.h_T(T + dT) - this.h_T(T - dT))./(2*dT);
	end

	function T = T_h(this, h)
		T = this.i_T_h(h - this.ref.h0);
	end

	function h = h_T(this, T)
		h = this.i_h_T(T) + this.ref.h0;
	end

	function sT = sT_T(this, T)
		sT = this.i_sT_T(T);
	end

	function ds = ds(this, P1, T1, P2, T2)
		sT_1 = this.sT_T(T1);
		sT_2 = this.sT_T(T2);

		% See eq. 7–39 Çengel
		ds = sT_2 - sT_1 - this.R.*log(P2./P1);
	end

	function dh = dh(this, T1, T2)
		dh = this.i_h_T(T2) - this.i_h_T(T1);
	end

	function s = s_ph(this, p, h)
		s = this.s_pT(p, this.T_h(h));
	end

	function s = s_pT(this, p, T)
		s = this.ref.s0 + this.ds(this.ref.P0, this.ref.T0, p, T);
	end

	function T = T_ps(this, p, s)
		% Çengel eq. 7–40 to obtain sT_1, and then get T_1 via an interpolation
		% table
		ds = s - this.ref.s0;
		sT0 = this.sT_T(this.ref.T0);

		sT1 = sT0 + this.R.*log(p./this.ref.P0) + ds;
		T = this.i_T_sT(sT1);
	end

	function T = T_ph(this, p, h)
		warning('Ideal gas, enthalpy not dependent on pressure, use T_h instead.');
		T = this.T_h(h);
	end

	function h = h_ps(this, p, s)
		T = this.T_ps(p, s);
		h = this.h_T(T);
	end
end


properties(Constant, Hidden)
	% Gas constant for air.
	R = 0.2871;

% The following data has been copied from the book in blocks as is, and has to be
% reshaped before it can be used.
	book_regular_5 = [
200
210
220
230
240
199.97
209.97
219.97
230.02
240.02
0.3363
0.3987
0.4690
0.5477
0.6355
142.56
149.69
156.82
164.00
171.13
1707.0
1512.0
1346.0
1205.0
1084.0
1.29559
1.34444
1.39105
1.43557
1.47824

250
260
270
280
285
250.05
260.09
270.11
280.13
285.14
0.7329
0.8405
0.9590
1.0889
1.1584
178.28
185.45
192.60
199.75
203.33
979.0
887.8
808.0
738.0
706.1
1.51917
1.55848
1.59634
1.63279
1.65055

290
295
298
300
305
290.16
295.17
298.18
300.19
305.22
1.2311
1.3068
1.3543
1.3860
1.4686
206.91
210.49
212.64
214.07
217.67
676.1
647.9
631.9
621.2
596.0
1.66802
1.68515
1.69528
1.70203
1.71865

310
315
320
325
330
310.24
315.27
320.29
325.31
330.34
1.5546
1.6442
1.7375
1.8345
1.9352
221.25
224.85
228.42
232.02
235.61
572.3
549.8
528.6
508.4
489.4
1.73498
1.75106
1.76690
1.78249
1.79783

340
350
360
370
380
340.42
350.49
360.58
370.67
380.77
2.149
2.379
2.626
2.892
3.176
242.82
250.02
257.24
264.46
271.69
454.1
422.2
393.4
367.2
343.4
1.82790
1.85708
1.88543
1.91313
1.94001

390
400
410
420
430
390.88
400.98
411.12
421.26
431.43
3.481
3.806
4.153
4.522
4.915
278.93
286.16
293.43
300.69
307.99
321.5
301.6
283.3
266.6
251.1
1.96633
1.99194
2.01699
2.04142
2.06533

440
450
460
470
480
441.61
451.80
462.02
472.24
482.49
5.332
5.775
6.245
6.742
7.268
315.30
322.62
329.97
337.32
344.70
236.8
223.6
211.4
200.1
189.5
2.08870
2.11161
2.13407
2.15604
2.17760

490
500
510
520
530
492.74
503.02
513.32
523.63
533.98
7.824
8.411
9.031
9.684
10.37
352.08
359.49
366.92
374.36
381.84
179.7
170.6
162.1
154.1
146.7
2.19876
2.21952
2.23993
2.25997
2.27967


580
590
600
610
620
586.04
596.52
607.02
617.53
628.07
14.38
15.31
16.28
17.30
18.36
419.55
427.15
434.78
442.42
450.09
115.7
110.6
105.8
101.2
96.92
2.37348
2.39140
2.40902
2.42644
2.44356

630
640
650
660
670
638.63
649.22
659.84
670.47
681.14
19.84
20.64
21.86
23.13
24.46
457.78
465.50
473.25
481.01
488.81
92.84
88.99
85.34
81.89
78.61
2.46048
2.47716
2.49364
2.50985
2.52589

680
690
700
710
720
691.82
702.52
713.27
724.04
734.82
25.85
27.29
28.80
30.38
32.02
496.62
504.45
512.33
520.23
528.14
75.50
72.56
69.76
67.07
64.53
2.54175
2.55731
2.57277
2.58810
2.60319

730
740
750
760
780
745.62
756.44
767.29
778.18
800.03
33.72
35.50
37.35
39.27
43.35
536.07
544.02
551.99
560.01
576.12
62.13
59.82
57.63
55.54
51.64
2.61803
2.63280
2.64737
2.66176
2.69013

800
820
840
860
880
821.95
843.98
866.08
888.27
910.56
47.75
52.59
57.60
63.09
68.98
592.30
608.59
624.95
641.40
657.95
48.08
44.84
41.85
39.12
36.61
2.71787
2.74504
2.77170
2.79783
2.82344

900
920
940
960
980
932.93
955.38
977.92
1000.55
1023.25
75.29
82.05
89.28
97.00
105.2
674.58
691.28
708.08
725.02
741.98
34.31
32.18
30.22
28.40
26.73
2.84856
2.87324
2.89748
2.92128
2.94468

1000
1020
1040
1060
1080
1046.04
1068.89
1091.85
1114.86
1137.89
114.0
123.4
133.3
143.9
155.2
758.94
776.10
793.36
810.62
827.88
25.17
23.72
23.29
21.14
19.98
2.96770
2.99034
3.01260
3.03449
3.05608

1100
1120
1140
1160
1180
1161.07
1184.28
1207.57
1230.92
1254.34
167.1
179.7
193.1
207.2
222.2
845.33
862.79
880.35
897.91
915.57
18.896
17.886
16.946
16.064
15.241
3.07732
3.09825
3.11883
3.13916
3.15916

1300
1320
1340
1360
1380
1395.97
1419.76
1443.60
1467.49
1491.44
330.9
352.5
375.3
399.1
424.2
1022.82
1040.88
1058.94
1077.10
1095.26
11.275
10.747
10.247
9.780
9.337
3.27345
3.29160
3.30959
3.32724
3.34474

1400
1420
1440
1460
1480
1515.42
1539.44
1563.51
1587.63
1611.79
450.5
478.0
506.9
537.1
568.8
1113.52
1131.77
1150.13
1168.49
1186.95
8.919
8.526
8.153
7.801
7.468
3.36200
3.37901
3.39586
3.41247
3.42892

1500
1520
1540
1560
1580
1635.97
1660.23
1684.51
1708.82
1733.17
601.9
636.5
672.8
710.5
750.0
1205.41
1223.87
1242.43
1260.99
1279.65
7.152
6.854
6.569
6.301
6.046
3.44516
3.46120
3.47712
3.49276
3.50829

1640
1660
1680
1700
1750
1806.46
1830.96
1855.50
1880.1
1941.6
 878.9
 925.6
 974.2
1025
1161
1335.72
1354.48
1373.24
1392.7
1439.8
5.355
5.147
4.949
4.761
4.328
3.55381
3.56867
3.58335
3.5979
3.6336

1800
1850
1900
1950
2000
2003.3
2065.3
2127.4
2189.7
2252.1
1310
1475
1655
1852
2068
1487.2
1534.9
1582.6
1630.6
1678.7
3.994
3.601
3.295
3.022
2.776
3.6684
3.7023
3.7354
3.7677
3.7994

2050
2100
2150
2200
2250
2314.6
2377.7
2440.3
2503.2
2566.4
2303
2559
2837
3138
3464
1726.8
1775.3
1823.8
1872.4
1921.3
2.555
2.356
2.175
2.012
1.864
3.8303
3.8605
3.8901
3.9191
3.9474
	];

	straggling_four = [
540
550
560
570
544.35
555.74
565.17
575.59
11.10
11.86
12.66
13.50
389.34
396.86
404.42
411.97
139.7
133.1
127.0
121.2
2.29906
2.31809
2.33685
2.35531
	];

	straggling_three = [
1200
1220
1240
1277.79
1301.31
1324.93
238.0
254.7
272.3
933.33
951.09
968.95
14.470
13.747
13.069
3.17888
3.19834
3.21751
	]

	straggling_twos = [
1260
1280
1348.55
1372.24
290.8
310.4
986.90
1004.76
12.435
11.835
3.23638
3.25510

1600
1620
1757.57
1782.00
791.2
834.1
1298.30
1316.96
5.804
5.574
3.52364
3.53879
 ]
end

end
