% This file is part of the +gasprops library
%
% This Source Code Form is subject to the terms of the Mozilla Public
% License, v. 2.0. If a copy of the MPL was not distributed with this
% file, You can obtain one at http://mozilla.org/MPL/2.0/.
%
% (C) Niels ter Meer

classdef gas

properties(Hidden)
	% The nonlinear solutions for T2_T1dh and T2_T1dsr are checked by substituting them back
	% into `dh` and `dsr` respectively. These have to be within this (absolute)
	% margin for them to be considered correct.
	BACKSUB_MARGIN = 1e-4;
end

properties(SetAccess = protected)
	f (1, :) double		{mustBeReal}
	trange (1, 2) double	{trangeMustBeRealNonnegativeAscending} = [0 inf]
	R (1, 1) double		{mustBePositive} = 1

	ref (1, 1) gasprops.refstate
	solver (1, 1) gasprops.solver.abc = gasprops.solver.newton
end

methods(Static)
	% Given a set of gasprops.gas-es, their fractions (by weight), and optionally a
	% reference state, compute the polynomial and temperature range of their mix.
	% `fractions` must sum to 1.
	function obj = mix(gasses, fractions, varargin)
	arguments
		gasses (:, 1)	gasprop.gas
		fractions (:, 1) {mustBePositive}
	end
	arguments(Repeating)
		varargin
	end
		assert(abs(1 - sum(fractions)) < 1e-6);
		f = sum(vertcat(gasses.f).*fractions);
		R = sum(vertcat(gasses.R).*fractions);

		tranges = vertcat(gasses.trange);
		trange = [min(tranges(:, 1)) max(tranges(:, 2))];

		obj = gasprops.gas(f, trange, R, varargin{:});
	end

	% Initialise a gas by the name from the gas_constants database (formerly gasprop)
	function obj = by_name(gas, varargin)
	arguments
		gas (1, :) char
	end
	arguments(Repeating)
		varargin
	end
		[R, trange, f] = gasprops.gas_constants(gas);
		obj = gasprops.gas(f, trange, R, varargin{:});
	end
end

methods
	function this = gas(f, trange, R, kwargs)
	arguments
		f (1, :) double		= 1
		trange (1, 2) double {trangeMustBeRealNonnegativeAscending} ...
					= [0 inf]
		R (1, 1) double {mustBePositive} ...
					= 1

		kwargs.ref		= gasprops.refstate()
		kwargs.solver gasprops.solver.abc {mustBeScalarOrEmpty} ...
					= gasprops.solver.newton.empty
		kwargs.backsub_margin (1, 1) double {mustBePositive} ...
					= 1e-4
	end
		this.f = f;
		this.trange = trange;
		this.R = R;

		this.ref = kwargs.ref;
		this.BACKSUB_MARGIN = kwargs.backsub_margin;

		if ~isempty(kwargs.solver)
			this.solver = kwargs.solver;
		elseif numel(f) == 4
			this.solver = gasprops.solver.algebraic4ext;
		elseif numel(f) == 1
			this.solver = gasprops.solver.algebraic1;
		else
			this.solver = gasprops.solver.newton;
		end

		% This throws an exception if the solver
		% is not compatible with the current gas
		this.solver.compatible_with(this);
	end

	% Set the zero enthalpy state at some temperature
	function other = h0_at_T(this, T)
		other = this.with_refstate(gasprops.refstate(T, this.ref.P0, 0, this.ref.s0));
	end

	% Set both enthalpy and entropy at zero at temperature `T`. The pressure from the
	% `parent' object is used as the zero pressure.
	function other = state0_at_T(this, T)
		other = this.with_refstate(gasprops.refstate(T, this.ref.P0, 0, 0));
	end

	% Derive a new gas from `this` with a new refstate `ref`
	function [other, dstate] = with_refstate(this, ref)
		other = gasprops.gas(this.f, this.trange, this.R, ...
			ref=ref, solver=this.solver, backsub_margin=this.BACKSUB_MARGIN);
		if nargout == 2
			dstate.P = ref.P0 - this.ref.P0;
			dstate.T = ref.T0 - this.ref.T0;
			dstate.h = ref.h0 - this.ref.h0;
			dstate.s = ref.s0 - this.ref.s0;
		end
	end

	% Derive a new gas from `this` with a new temperature range `trange`. `trange`
	% must be strictly a subset of the `this`'s `trange`, unless
	% `just_warn_dont_err=true`, in which case only a warning is emitted.
	function other = with_trange(this, trange, kwargs)
	arguments
		this
		trange
		kwargs.just_warn_dont_err = false
	end
		if kwargs.just_warn_dont_err
			errfn = @warning;
		else
			errfn = @error;
		end

		if  trange(1) < this.trange(1)
			errfn('gasprops:gas:with_trange:extends_below', ...
				'New trange extends below what is known valid: from %f to %f', this.trange(1), trange(1));
		end

		if kwargs.warn && trange(2) > this.trange(2)
			errfn('gasprops:gas:with_trange:extends_below', ...
				'New trange extends above what is known valid: from %f to %f', this.trange(2), trange(2));
		end

		other = gasprops.gas(this.f, trange, this.R, ...
			ref=this.ref, solver=this.solver, backsub_margin=this.BACKSUB_MARGIN);
	end

	% Derive a new gas from `this` with another nonlinear solver. This solver must be
	% a subclass of `gasprops.solver.abc` (the solvers' abstract base class).
	function other = with_solver(this, solver)
		other = gasprops.gas(this.f, this.trange, this.mmass, ...
			ref=this.ref, solver=solver, backsub_margin=this.BACKSUB_MARGIN);
	end
end

methods
	%
	function f = f_cv(this)
		f = this.f;
		f(end) = f(end) - this.R;
	end

	function cp = cp(this, T)
	arguments
		this (1, 1) gasprops.gas
		T {tempcheck(T, this)}
	end
		cp = polyval(this.f, T);
	end

	function cv = cv(this, T)
		% We can also directly compute cv via the dv polynomial. But that would
		% basically be duplicating the cp method, so this is easier and sturdyer
		cv = this.cp(T) - this.R;
	end

	function g = gamma(this, T)
		cp = this.cp(T);
		% Don't call Cv, which would call Cp again. Just compute Cv here
		g = cp./(cp - this.R);
	end

	function varargout = dh(this, T1, T2)
		try
			[varargout{1:nargout}] = dx(this.f, this, T1, T2);
		catch e
			throw(addCause(MException('gasprops:gas:dh_fail', ...
				'Failed to compute difference in enthalpy'), ...
				e));
		end
	end

	function varargout = du(this, T1, T2)
		try
			[varargout{1:nargout}] = dx(this.f_cv, this, T1, T2);
		catch e
			throw(addCause(MException('gasprops:gas:du_fail', ...
				'Failed to compute difference in internal energy'), ...
				e));
		end
	end

	function h = h_T(this, T)
		h = this.ref.h0 + this.dh(this.ref.T0, T);
	end

	function u = u_T(this, T)
		u = this.ref.u0 + this.du(this.ref.T0, T);
	end

	function [T, e] = T_h(this, h)
		dh = h - this.ref.h0;
		[T, e] = this.T2_T1dh(this.ref.T0, dh);
	end

	function [T, e] = T_u(this, u)
		du = u - this.ref.u0;
		[T, e] = this.T2_T1du(this.ref.T0, du);
	end

	function [T2, e] = T2_T1dh(this, T1, dh)
	arguments
		this (1, 1) gasprops.gas
		T1	{tempcheck(T1, this)}
		dh	{propertyMustBeReal(dh, 'enthalpy')}
	end
		% Apparently Matlab doesn't like it when you make a function_handle
		% when the function to call is too deep in the object/struct tree, so we
		% have to do this dance via `x`.
		x = this.solver;

		try
			[T2, e] = this.T2_T1dx(T1, dh, @x.T2_T1dh, @this.dh);
		catch e
			throw(addCause(MException('gasprops:gas:T2_T1dh', ...
				'Error computing temperature for enthalpy difference'), ...
				e))
		end
	end

	function [T2, e] = T2_T1du(this, T1, du)
	arguments
		this (1, 1) gasprops.gas
		T1	{tempcheck(T1, this)}
		du	{propertyMustBeReal(du, 'internal energy')}
	end
		% Apparently Matlab doesn't like it when you make a function_handle
		% when the function to call is too deep in the object/struct tree, so we
		% have to do this dance via `x`.
		x = this.solver;

		try
			[T2, e] = this.T2_T1dx(T1, du, @x.T2_T1du, @this.du);
		catch e
			throw(addCause(MException('gasprops:gas:T2_T1du', ...
				'Error computing temperature for internal energy difference'), ...
				e))
		end
	end

	function ds = ds(this, T1, T2, P1, P2)
		ds = this.dsr(T1, T2, P2./P1);
	end

	function ds = dsr(this, T1, T2, r)
	arguments
		this (1, 1) gasprops.gas
		T1	{tempcheck(T1, this)}
		T2	{tempcheck(T2, this)}
		r	{PratioMustBePositive}
	end
		F = polyint(this.f(1:end-1));
		ds = polyval(F, T2) - polyval(F, T1) + this.f(end).*log(T2./T1) - this.R.*log(r);
	end

	function s = s_ph(this, P, h)
		T = this.T_h(h);
		s = this.s_pT(P, T);
	end

	function s = s_pu(this, P, u)
		T = this.T_u(u);
		s = this.s_pT(P, T);
	end

	function s = s_pT(this, P, T)
		s = this.ref.s0 + this.ds(this.ref.T0, T, this.ref.P0, P);
	end

	function [T2, e] = T2_T1dsr(this, T1, ds, r)
	arguments
		this (1, 1) gasprops.gas
		T1	{tempcheck(T1, this)}
		ds	{propertyMustBeReal(ds, 'entropy')}
		r	{PratioMustBePositive}
	end
		% Just as with computing the temperature based on an enthalpy difference,
		% it is also relatively easy to compute what the range of good values for
		% the entropy difference is, based on the valid temperature range and the
		% given pressure ratio. Only in this case the error message is slightly
		% less useful, because it can be due to the combination of entropy
		% difference and pressure ratio that cause the temperature to move out of
		% the valid range.
		dsmin = this.dsr(T1, this.trange(1), r);
		dsmax = this.dsr(T1, this.trange(2), r);
		if any(ds < dsmin, 'all')
			throw(MException('gasprops:gas:T_ps:too_low', ...
				'The pressure ratio and/or entropy difference provided correspond to a temperature below the supported range'))
		end

		if any(ds > dsmax, 'all')
			throw(MException('gasprops:gas:T_ps:too_high', ...
				'The pressure ratio and/or entropy difference provided correspond to a temperature above the supported range'))
		end

		T2 = this.solver.T2_T1dsr(this, T1, ds, r);

		% By backsubstituting in the computed temperature one can check the
		% accuracy of the solver's result. Since this is a relatively cheap
		% operation this is worth it.
		try
			e = this.dsr(T1, T2, r) - ds;
		catch ex
			% Catching this exception and rethrowing it as a cause gives some
			% context to this fault. If it is just left uncaught it's
			% confusing because why would dsr be called when trying to
			% compute a temperature?
			throw(addCause(MException('gasprops:gas:T2_T1dsr:backsub_err', ...
				'Failure backsubstituting computed temperature'), ex));
		end

		abs_e = abs(e);
		if any(abs_e > this.BACKSUB_MARGIN, 'all')
			max_e = max(abs_e, [], 'all');
			throw(MException('gasprops:gas:T2_T1dsr:backsub_mismatch' ...
			, 'Backsubstituted solver solution does not match some input values within margin (max abs err: %.2e, tol: %.2e, %.2g%% over tol)' ...
			, max_e, this.BACKSUB_MARGIN, (max_e./this.BACKSUB_MARGIN - 1)*100))
		end
	end

	function [T, e] = T_ps(this, p, s)
		ds = s - this.ref.s0;
		r  = p./this.ref.P0;

		[T, e]  = this.T2_T1dsr(this.ref.T0, ds, r);
	end

	function [h, e] = h_ps(this, p, s)
		[T, e] = this.T_ps(p, s);
		h = this.h_T(T);
	end

	function [u, e] = u_ps(this, p, s)
		[T, e] = this.T_ps(p, s);
		u = this.u_T(T);
	end

	% Compute a pressure ratio as a function of the entropy change caused by that
	% pressure ratio
	function r = r_dsP(this, dsP)
		r = exp(-dsP./this.R);
	end

	% Given a total
	function r = r_dsdsT(this, ds, dsT)
		r = this.r_dsP(ds - dsT);
	end

	function r = r_dsT1T2(this, ds, T1, T2)
		try
			% dsr with a pressure ratio 1 one computes the entropy change
			% caused by a temperature difference, i.e. Δs°
			dsT = this.dsr(T1, T2, 1);
		catch e
			throw(addCause(MException('gasprops:gas:r_dsT1T2:bad_dsT_temps', ...
				'Failure to compute entropy change caused by temperature'), ...
			e))
		end
		r = this.r_dsdsT(ds, dsT);
	end

	function p = p_sT(this, s, T)
		ds = s - this.ref.s0;
		p = this.ref.P0.*this.r_dsT1T2(ds, this.ref.T0, T);
	end
end

methods(Access=protected)
	% This internal method computes T2 based on T1 and some difference dx. What dx
	% means depends on what polynomial is used; dh/cp and du/cv are computed
	% similarly but just with different polynomials. This code is thus shared between
	% T2_T1dh and T2_T1du.
	%
	% It does not make sense for this method to be publicly accessible, hence it is
	% marked as protected.
	function [T2, e] = T2_T1dx(this, T1, dx, solver_fn, dx_fn)
	arguments
		this (1, 1) gasprops.gas
		T1	{tempcheck(T1, this)}
		dx	{propertyMustBeReal(dx, 'dx')}
		solver_fn (1, 1) {mustBeCallable}
		dx_fn (1, 1) {mustBeCallable}
	end
		% Running the solver with unreasonable inputs yields rather unclear error
		% messages — they blaim it on all the inputs, not one in particular.
		% Computing what the range of values for which valid answers can be
		% expected is relatively cheap. If the input difference is outside that
		% range, one can error out early with a good message.
		dxmin = dx_fn(T1, this.trange(1));
		dxmax = dx_fn(T1, this.trange(2));
		if any(dx < dxmin, 'all')
			throw(MException('gasprops:gas:T2_T1dx:dx_too_low', ...
				'The enthalpy difference provided corresponds to a temperature below the supported range'))
		end

		if any(dx > dxmax, 'all')
			throw(MException('gasprops:gas:T2_T1dx:dx_too_high', ...
				'The enthalpy difference provided corresponds to a temperature above the supported range'))
		end

		T2 = solver_fn(this, T1, dx);

		% By backsubstituting in the computed temperature one can check whether
		% the solver's result is correct — it has to end up at (approximately)
		% the same difference.
		try
			e = dx_fn(T1, T2) - dx;
		catch ex
			% Catching this exception and rethrowing it as a cause gives some
			% context to this fault. If it is just left uncaught it's
			% confusing because why would the dx method be called when trying
			% to compute a temperature?
			throw(addCause(MException('gasprops:gas:T2_T1dx:backsub_err', ...
				'Failure backsubstituting computed temperature'), ex))
		end

		if any(abs(e) > this.BACKSUB_MARGIN, 'all')
			max_e = max(e, [], 'all');
			throw(MException('gasprops:gas:T2_T1dx:backsub_mismatch' ...
			, 'Backsubstituted solver solution does not match input within margin (max rel err: %.2e, tol: %.2e, %.2g%% over tol)' ...
			, max_e, this.BACKSUB_MARGIN, 100*(max_e./this.BACKSUB_MARGIN - 1)));
		end
	end
end

% Methods implementing the ideal gas law relations, provided for completeness.
%
% NOTE: These only work with a coherent set of units, i.e. kg/m³, Pa, and K. The bar is
% not a coherent unit.
methods
	function v = v_pT(this, p, T)
	arguments
		this
		p {mustBePositive}
		% We don't need an in-range check on this T because the computation
		% herein does not depend on the C_p polynomial.
		T {mustBePositive}
	end
		v = (this.R.*T)./p;
	end

	function v = v_ph(this, p, h)
	arguments
		this
		p {mustBePositive}
		h
	end
		T = this.T_h(h);
		v = this.v_pT(p, T);
	end

	function v = v_pu(this, p, u)
	arguments
		this
		p {mustBePositive}
		u
	end
		T = this.T_u(u);
		v = this.v_pT(p, T);
	end

	function v = v_sT(this, s, T)
		% Temperature range check is done down the stack of p_sT
		p = this.p_sT(s, T);
		v = this.v_pT(p, T);
	end

	function v = v_sh(this, s, h)
		T = this.T_h(h);
		v = this.v_sT(s, T);
	end

	function v = v_su(this, s, u)
		T = this.T_u(u);
		v = this.v_sT(s, T);
	end

	function T = T_pv(this, p, v)
		T = (p.*v)./this.R;
	end

	function h = h_pv(this, p, v)
		h = this.h_T(this.T_pv(p, v));
	end

	function u = u_pv(this, p, v)
		u = this.u_T(this.T_pv(p, v));
	end

	function p = p_Tv(this, T, v)
		p = (this.R.*T)./v;
	end

	function s = s_vh(this, v, h)
		T = this.T_h(h);
		s = this.s_vT(v, T);
	end

	function s = s_vu(this, v, u)
		T = this.T_u(u);
		s = this.s_vT(v, T);
	end
end
end

function [dx, avg_cx] = dx(f, gas, T1, T2)
arguments
	f (1, :) double
	gas (1, 1) gasprops.gas
	T1 {tempcheck(T1, gas)}
	T2 {tempcheck(T2, gas)}
end
	F = polyint(f);
	dx = polyval(F, T2) - polyval(F, T1);

	if nargout > 1
		avg_cx = dx./(T2 - T1);
	end
end

% Check whether the temperature is valid for the given gas model
function tempcheck(T, gas)
arguments
	% Don't add any further checks on the temperature argument because that's the
	% whole point of this function
	T double
	gas (1, 1) gasprops.gas
end

	if ~isreal(T)
		throw(MException('gasprops:gas:tempcheck:not_real', ...
			'Temperature argument must be real valued'));
	end

	tmin = gas.trange(1);
	tmax = gas.trange(2);
	below_minimum = any(T < tmin, 'all');
	above_maximum = any(T > tmax, 'all');

	if below_minimum && above_maximum
		throwAsCaller(MException(['gasprops:gas:T:out_of_range'], ...
			'Some temperatures are below the minimum and above the maximum supported temperatures of %.0f and %.0f respectively', tmin, tmax));
	elseif below_minimum
		throwAsCaller(MException(['gasprop:gas:T:too_low'], ...
			'Some temperature is below the minimum supported of %.0f', tmin));
	elseif above_maximum
		throwAsCaller(MException(['gasprop:gas:T:too_high'], ...
			'Some temperature is above the maximum supported of %.0f', tmax));
	end
end

function trangeMustBeRealNonnegativeAscending(x)
	if ~isreal(x)
		throwAsCaller(MException('gasprops:gas:trange:mustBeReal', 'Temperature range must be real'));
	end

	if x <= 0
		throwAsCaller(MException('gasprops:gas:trange:mustBeNonNegative', 'Temperature range must be non-negative'));
	end

	if ~issorted(x)
		throwAsCaller(MException('gasprops:gas:trange:mustBeAscending', 'Temperature range must be ascending'));
	end
end

function PratioMustBePositive(x)
	if ~isreal(x)
		throwAsCaller(MException('gasprops:gas:pratio:mustBeReal', 'Pressure ratio must be real'))
	end

	if x <= 0
		throwAsCaller(MException('gasprops:gas:pratio:mustBePositive', 'Pressure ratio must be positive'))
	end
end

function propertyMustBeReal(x, name)
	if ~isreal(x)
		throwAsCaller(MException(['gasprops:gas:' name ':mustBeReal'], 'Real value required for %s', name));
	end
end

function mustBeCallable(x)
	mustBeA(x, 'function_handle');
end
