% This file is part of the +gasprops library
%
% This Source Code Form is subject to the terms of the Mozilla Public
% License, v. 2.0. If a copy of the MPL was not distributed with this
% file, You can obtain one at http://mozilla.org/MPL/2.0/.
%
% (C) Niels ter Meer

% This function has been taken from the `gasprop` function, spiritually the predecessor
% of this work. Numerical data has been taken from "Thermodynamics: An Engineering
% Approach" by Yunus A. Çengel et al., 8th edition, table A–2(c) (SI).
%
% Implementation based on the work by E.S.J. Beitler and Niels ter Meer (C)

function [R, trange, f] = gas_constants(gas)
% Gas constants "database". It defines (constants of) a polynomial, determined
% emperically, to approximate the specific heat capacity, of the form:
%     cp ≈ f = ( a + bT + cT² + dT³ )/ molar_mass
% It also defines the temperatures range where this approximation is valid.

% Definition of the molar mass of every atom used in this function. This is needed for
% the conversion to common used Cp values.
N = 14.00674;       %Nitrogen
O = 15.9994;        %Oxygen
H = 1.00794;        %Hydrogen
C = 12.0107;        %Carbon
S = 32.066;         %Sulfur
Cl = 35.4527;       %Chloride

Ru = 8.31447;

% No gas has a different minimum temperature; set it here globally.
tmin = 273;

gas = upper(gas);

switch gas
    case 'N2'
        a = 28.90;
        b = -0.1571e-2;
        c = 0.8081e-5;
        d = -2.873e-9;
        molar_mass = N*2;

	tmax = 1800;
    case 'O2'
        a = 25.48;
        b = 1.520e-2;
        c = -0.7155e-5;
        d = 1.312e-9;
        molar_mass = O*2;

	tmax = 1800;
    case 'AIR'
        a = 28.11;
        b = 0.1967e-2;
        c = 0.4802e-5;
        d = -1.966e-9;
        molar_mass = 28.9647;

	tmax = 1800;
    case 'H2'
       a = 29.11;
       b = -0.1916e-2;
       c = 0.4003e-5;
       d = -0.8704e-9;
       molar_mass = H*2;

       tmax = 1800;
    case 'CO'
       a = 28.16;
       b = 0.1675e-2;
       c = 0.5372e-5;
       d = -2.222e-9;
       molar_mass = C + O;

       tmax = 1800;
    case 'CO2'
       a = 22.26;
       b = 5.981e-2;
       c = -3.501e-5;
       d = 7.469e-9;
       molar_mass = C + 2*O;

       tmax = 1800;
    case 'H2O'
       a = 32.24;
       b = 0.1923e-2;
       c = 1.055e-5;
       d = -3.595e-9;
       molar_mass = H*2 + O;

       tmax = 1800;
    case 'NO'
       a = 29.34;
       b = -0.09395e-2;
       c = 0.9747e-5;
       d = -4.187e-9;
       molar_mass = N + O;

       tmax = 1500;
    case 'N2O'
       a = 24.11;
       b = 5.8632e-2;
       c = -3.562e-5;
       d = 10.58e-9;
       molar_mass = N*2 + O;

       tmax = 1500;
    case 'NO2'
       a = 22.9;
       b = 5.715e-2;
       c = -3.52e-5;
       d = 7.87e-9;
       molar_mass = N + O*2;

       tmax = 1500;
    case 'NH3'
       a = 27.568;
       b = 2.5630e-2;
       c = 0.99072e-5;
       d = -6.6909e-9;
       molar_mass = N + H*3;

       tmax = 1500;
    case 'S2'
       a = 27.21;
       b = 2.218e-2;
       c = -1.628e-5;
       d = 3.986e-9;
       molar_mass = S*2;

       tmax = 1800;
    case 'SO2'
       a = 25.78;
       b = 5.795e-2;
       c = -3.812e-5;
       d = 8.612e-9;
       molar_mass = S + O*2;

       tmax = 1800;
    case 'SO3'
       a = 16.40;
       b = 14.58e-2;
       c = -11.20e-5;
       d = 32.42e-9;
       molar_mass = S + O*3;

       tmax = 1300;
    case 'C2H2'
       a = 21.8;
       b = 9.2143e-2;
       c = -6.5278e-5;
       d = 18.21e-9;
       molar_mass = C*2 + H*2;

       tmax = 1500;
    case 'C6H6'
       a = -36.22;
       b = 48.475;
       c = -31.57e-5;
       d = 77.62e-9;
       molar_mass = C*6 + H*6;

       tmax = 1500;
    case 'CH4O'
       a = 19.0;
       b = 9.152e-2;
       c = -1.22e-5;
       d = -8.039e-9;
       molar_mass = c + H*4 + O;

       tmax = 1000;
    case 'C2H6O'
       a = 19.9;
       b = 20.96e-2;
       c = -10.38e-5;
       d = 20.05e-9;
       molar_mass = C*2 + H*6 + O;

       tmax = 1500;
    case 'HCL'
       a = 30.33;
       b = -0.7620e-2;
       c = 1.327e-5;
       d = -4.338e-9;
       molar_mass = H + Cl;

       tmax = 1500;
    case 'CH4'
       a = 19.89;
       b = 5.024e-2;
       c = 1.269e-5;
       d = -11.01e-9;
       molar_mass = C + H*4;

       tmax = 1500;
    case 'C2H6'
       a = 6.900;
       b = 17.27e-2;
       c = -6.406e-5;
       d = 7.285e-9;
       molar_mass = C*2 + H*6;

       tmax = 1500;
    case 'C3H8'
       a = -4.04;
       b = 30.48e-2;
       c = -15.72e-5;
       d = 31.74e-9;
       molar_mass = C*3 + H*8;

       tmax = 1500;
    case 'C4H10_N'          %n-Butane
       a = 3.96;
       b = 37.15e-2;
       c = -18.34e-5;
       d = 35.00e-9;
       molar_mass = C*4 + H*10;

       tmax = 1500;
    case 'C4H10_I'          %i-Butane
       a = -7.913;
       b = 41.60e-2;
       c = -23.01e-5;
       d = 49.91e-9;
       molar_mass = C*4 + H*10;

       tmax = 1500;
    case 'C5H12'            %n-Pentane
       a = 6.774;
       b = 45.43e-2;
       c = -22.46e-5;
       d = 42.29e-9;
       molar_mass = C*5 + H*12;

       tmax = 1500;
    case 'C6H14'          %n-Hexane
       a = 6.938;
       b = 55.22e-2;
       c = -28.65e-5;
       d = 57.69e-9;
       molar_mass = C*6 + H*14;

       tmax = 1500;
    case 'C2H4'
       a = 3.95;
       b = 15.64e-2;
       c = -8.344e-5;
       d = 17.67e-9;
       molar_mass = C*2 + H*4;

       tmax = 1500;
    case 'C3H6'
       a = 3.15;
       b = 23.83e-2;
       c = -12.18e-5;
       d = 24.62e-9;
       molar_mass = C*2 + H*4;

       tmax = 1500;
    otherwise
        error('gasprop:gas_not_found', 'Gas not found, check spelling and/or manual.')
end

% If just naively evaluated, with a large vector of temperatures for T, then MatLab has
% to divide that whole vector by the molar mass. Instead, the molar mass can be folded
% into the constants (m := molar_mass here):
%     f = a/m + b/m T + c/m T² + d/m T³
% Folding the molar mass into the polynomial's constants also makes gas_constants easier
% to use, as it is one return value fewer to move around.
%
% Since polyval is used to evaluate the polynomial (more on that elsewhere), the
% constants are written in "reverse" order, since the highest order comes first in
% polyval's API.
f = [d c b a]./molar_mass;
trange = [tmin tmax];
R = Ru./molar_mass;
end
