% This file is part of the +gasprops library
%
% This Source Code Form is subject to the terms of the Mozilla Public
% License, v. 2.0. If a copy of the MPL was not distributed with this
% file, You can obtain one at http://mozilla.org/MPL/2.0/.
%
% (C) Niels ter Meer

classdef refstate

properties(SetAccess=protected)
	T0
	P0
	h0
	s0
	u0
end

methods(Static)
	function obj = with(kwargs)
	arguments
		kwargs.T0 = 273.15
		kwargs.P0 = 100
		kwargs.h0 = 0
		kwargs.s0 = 0
		kwargs.u0 = 0
	end
		obj = gasprops.refstate(kwargs.T0, kwargs.P0, kwargs.h0, kwargs.s0, kwargs.u0);
	end
end

methods
	function this = refstate(T0, P0, h0, s0, u0)
	arguments
		T0 (1, 1) double {mustBeNonnegative} = 273.15	% 0°C
		P0 (1, 1) double {mustBeNonnegative} = 100	% 1 bar = 100 kPa
		h0 (1, 1) double = 0
		s0 (1, 1) double = 0
		u0 (1, 1) double = 0
	end
		this.T0 = T0;
		this.P0 = P0;
		this.s0 = s0;
		this.h0 = h0;
		this.u0 = u0;
	end
end

end
