% A wrapper around the +gasprops package in the spirit of XSteam
%
% To the students reading this: you can also call the gas model directly without having
% to go through this stringy interface. Instead of storing a character array representing
% the gas you want to model, you can store an object instead, which has methods to
% compute thermodynamic states. You'll have working tab completion in your editor and
% error messages which make a tad more sense. Email n.termeer@student.utwente.nl if you
% have any questions on this.
function varargout = gasProperties(name, fn, varargin)
arguments
	name (1, :) char {mustBeText}
	fn (1, :) char {mustBeText}
end
arguments(Repeating)
	varargin
end
	% An allowlist to not let people call some shoot-yourself-in-the-foot methods of
	% gasprop.gas, e.g. configuration methods, internals, etc.
	expose = {
		'R'
		'trange'

		'cp'
		'cv'
		'gamma'

		'h_T'
		'h_ps'
		'h_pv'

		'u_T'
		'u_ps'
		'u_pv'

		's_ph'
		's_pu'
		's_pT'
		's_vh'
		's_vu'

		'T_h'
		'T_u'
		'T_ps'
		'T_pv'

		'p_sT'
		'p_Tv'

		'v_pT'
		'v_ph'
		'v_pu'
		'v_sT'
		'v_sh'
		'v_su'
	};

	if strcmp(fn, 'version')
		v.major = 1;
		v.minor = 0;
		v.patch = 2;
		varargout{1} = v;
		return
	end

	% 1 bar = 100 kPa. The pressure unit must be kPa because we get an extra
	% factor 1000x from working in kJ.
	ref = gasprops.refstate(273.15, 1e2, 0, 0);
	try
		gas = gasprops.gas.by_name(name, ref=ref);
	catch e
		e = addCause(MException('gasprops:wrapper:nosuchgas', 'There exists no gas with the name `%s`', name), e);
		throw(e)
	end

	switch fn
	case expose
		try
			[varargout{1:nargout}] = gas.(fn)(varargin{:});
		catch e
			e = addCause(MException('gasprops:wrapper:callfailed', 'Call `%s` failed for gas `%s`', fn, name), e);
			throw(e)
		end
	otherwise
		error('gasprops:wrapperSI:unknown_fn', 'Unknown or non-public function `%s`', fn);
	end
end
