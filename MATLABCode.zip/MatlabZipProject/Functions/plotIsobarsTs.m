function [Isobars] = plotIsobarsTs(Pressures,s_min,s_max)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
Entropy = linspace(s_min,s_max,500);
Temperature =  zeros(1,500);


for i=1:length(Pressures)
    for j=1:500
        Temperature(j) = XSteam('T_ps',Pressures(i), Entropy(j));
    end
    Isobars = plot(Entropy,Temperature,'k', LineWidth=1);
    hold on
end