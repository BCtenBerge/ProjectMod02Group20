% Script for plotting flow diagrams (such as Sankey and Grassman)
% Jos Havinga
% ??/12/2019
% 15/12/2020: updated comments

% The components structure should be defined as explained in the Session 4
% explanation.
% The defaults and flowTypes structures can be created using the
% defaultSettins variable.

% If defaults has not yet been defined, run the defaultSettings script
if ~exist('defaults','var')
    defaultSettings
end

% Add all settings to the components structure using the setDefaults
% function. The setDefaults function will add all required properties to
% the components structure, if they have not already been defined.
components = setDefaults(components,defaults,flowTypes);


% Get values of all incoming flows. The values are defined in the outgoing
% flows. Therefore, the matching outgoing flow must be found first, and
% then used to get the correct values.
% For each component
for i = 1:length(components)
    % If the component has incoming flows
    if isfield(components(i),'in')
        % For each incoming flow
        for j = 1:length(components(i).in)
            % Get the component number of the source of this flow
            source_block = components(i).in(j).source;
            % Find which of the outgoing flows of the source component
            % point to component i
            source_arrow = find([components(source_block).out(:).target]==i);
            % Get the corresponding value
            components(i).in(j).value = components(source_block).out(source_arrow).value;
        end
    end
end

% Each arrow connects multiple points. A 'h' arrow connects 2 coordinates, 
% a 'hvh' connects 4 coordinates, a 'hvhvh' arrow connects 6 coordinates,
% etc. All coordinates except the first and last are set in this part of
% the code.
% For all components
for i = 1:length(components)
    % If there are outgoing flows
    if isfield(components(i),'out')
        % For each outgoing flow
        for j = 1:length(components(i).out)
            % The 'shape' property defines how many coordinates the arrow
            % will connect
            components(i).out(j).x = NaN(length(components(i).out(j).shape) + 1,1);
            components(i).out(j).y = NaN(length(components(i).out(j).shape) + 1,1);
            % If shape is not only horizontal, it has vertical intermediate
            % lines
            if length(components(i).out(j).shape) > 1
                % If verticalLinesX vector was not correctly set
                if (length(components(i).out(j).shape) - 1)/2 ~= length(components(i).out(j).verticalLinesX)
                    error(['Number of entries of components(' num2str(i) ...
                        ').out(' num2str(j) ').verticalLinesX must be ' ...
                        num2str((length(components(i).out(j).shape) - 1)/2) ...
                        ', because components(' num2str(i) ').out(' num2str(j) ...
                        ').shape is ' components(i).out(j).shape '.'])
                else
                    % Set the x-coordinates of the points to be connected,
                    % based on the values of the verticalLinesX property
                    components(i).out(j).x(2:2:(end-1)) = components(i).out(j).verticalLinesX;
                    components(i).out(j).x(3:2:(end-1)) = components(i).out(j).verticalLinesX;
                end
            end
            % If the length of the shape property is larger than 3 (e.g.
            % 'hvhvh') there will also be horizontal intermediate lines of
            % which the y-coordinates must have been defined in the
            % horizontalLinesY property
            if length(components(i).out(j).shape) > 3
                % If horizontalLinesY property was not correctly set
                if (length(components(i).out(j).shape) - 3)/2 ~= length(components(i).out(j).horizontalLinesY)
                    error(['Number of entries of components(' num2str(i) ...
                        ').out(' num2str(j) ').horizontalLinesY must be ' ...
                        num2str((length(components(i).out(j).shape) - 3)/2) ...
                        ', because components(' num2str(i) ').out(' num2str(j) ...
                        ').shape is ' components(i).out(j).shape '.'])
                else
                    % Set the y-coordinates of the points to be connected,
                    % based on the values of the horizontalLinesY property
                    components(i).out(j).y(3:2:(end-2)) = components(i).out(j).horizontalLinesY;
                    components(i).out(j).y(4:2:(end-1)) = components(i).out(j).horizontalLinesY;
                end
            end
        end
    end
end

% Now, determine all coordinates of the start and endpoints of the arrow.
% These coordinates must be based on the values of all flows that are
% incoming/outgoing to that block
for i = 1:length(components)
    % Determine the total widht of the incoming flows
    if isfield(components(i),'in') && ~isempty(components(i).in)
        plot_widths = max([components(i).in(:).value]*defaults.norm_fact,defaults.minArrowWidth);
        components(i).width_in = sum(plot_widths);
        for j = 1:length(components(i).in)
            % get relative input positions
            components(i).in(j).y_relative = components(i).width_in/2 - (sum(plot_widths(1:(j-1))) + plot_widths(j)/2);
        end
    else
        components(i).width_in = 0;
    end
    
    % Determine the total width of the outgoing flows
    if isfield(components(i),'out') && ~isempty(components(i).out)
        plot_widths = max([components(i).out(:).value]*defaults.norm_fact,defaults.minArrowWidth);
        components(i).width_out = sum(plot_widths);
        for j = 1:length(components(i).out)
            % get relative output positions
            components(i).out(j).y_relative = components(i).width_out/2 - (sum(plot_widths(1:(j-1))) + plot_widths(j)/2);
        end
    else
        components(i).width_out = 0;
    end
    
    % If the height of the block is not set, is must be equal to the
    % maximum value of the total incoming or of the total outgoing width
    if ~isfield(components(i),'blockHeight') || isempty(components(i).blockHeight)
        components(i).blockHeight = max(components(i).width_out,components(i).width_in);
    end
    if ~components(i).drawBlock
        components(i).blockWidth = 0;
    end
    
    % If the blockHeight is not equal to the outgoing width, the relative
    % y-coordinate of the arrows must change if the alignment is 't' or 'b'
    dy = (components(i).blockHeight - components(i).width_out)/2;
    if strcmpi(components(i).outputsAlignment,'t')
        for j = 1:length(components(i).out)
            components(i).out(j).y_relative = components(i).out(j).y_relative + dy;
        end
    elseif strcmpi(components(i).outputsAlignment,'b')
        for j = 1:length(components(i).out)
            components(i).out(j).y_relative = components(i).out(j).y_relative - dy;
        end
    end
    
    % If the blockHeight is not equal to the incoming width, the relative
    % y-coordinate of the arrows must change if the alignment is 't' or 'b'
    dy = (components(i).blockHeight - components(i).width_in)/2;
    if strcmpi(components(i).inputsAlignment,'t')
        for j = 1:length(components(i).in)
            components(i).in(j).y_relative = components(i).in(j).y_relative + dy;
        end
    elseif strcmpi(components(i).inputsAlignment,'b')
        for j = 1:length(components(i).in)
            components(i).in(j).y_relative = components(i).in(j).y_relative - dy;
        end
    end
end



for i = 1:length(components)
%     Determine center coordinate of each block
    if ischar(components(i).coordinateY)
        % inhterit y position from source
        % source arrow must be defined!
        source_block = components(i).in(str2num(components(i).coordinateY(2:end))).source;
        source_arrow = find([components(source_block).out(:).target]==i);
        components(i).coordinateY = components(source_block).out(source_arrow).y(end) - components(i).in(str2num(components(i).coordinateY(2:end))).y_relative;
    elseif strcmpi(components(i).referencePoint,'t')
        components(i).coordinateY = components(i).coordinateY - components(i).blockHeight/2;
    elseif strcmpi(components(i).referencePoint,'b')
        components(i).coordinateY = components(i).coordinateY + components(i).blockHeight/2;
    end
    
    if isfield(components(i),'out') && ~isempty(components(i).out)
        for j = 1:length(components(i).out)
            % Set initial coordinates of each out-flow
            components(i).out(j).y(1) = components(i).coordinateY + components(i).out(j).y_relative;
            components(i).out(j).x(1) = components(i).coordinateX + components(i).blockWidth/2;
            if ischar(components(components(i).out(j).target).coordinateY)
                source_arrow = str2num(components(components(i).out(j).target).coordinateY(2:end));
                source_block = components(components(i).out(j).target).in(source_arrow).source;
                if  source_block == i
                    % target block inherits, so make complete trajectory
                    for k = 1:length(components(i).out(j).shape)
                        if strcmpi(components(i).out(j).shape(k),'h')
                            components(i).out(j).y(k+1) = components(i).out(j).y(k);
                        elseif strcmpi(components(i).out(j).shape(k),'v')
                            components(i).out(j).x(k+1) = components(i).out(j).x(k);
                        end
                    end
                    components(i).out(j).x(length(components(i).out(j).shape) + 1) = components(components(i).out(j).target).coordinateX - components(components(i).out(j).target).blockWidth/2;
                end
            end
        end
    end
end

% Create a new figure
fig = figure;
% Plot all arrows
% For each component
for i = 1:length(components)
    % If it has outgoing flows
    if isfield(components(i),'out') && ~isempty(components(i).out)
        % For each outgoing flow
        for j = 1:length(components(i).out)
            % Set all arrow x- and y-coordinates
            target_block = components(i).out(j).target;
            target_arrow = find([components(target_block).in(:).source]==i);
            components(i).out(j).x(length(components(i).out(j).shape) + 1) = components(target_block).coordinateX - components(target_block).blockWidth/2;
            components(i).out(j).y(length(components(i).out(j).shape) + 1) = components(target_block).coordinateY + components(target_block).in(target_arrow).y_relative;
            for k = 1:length(components(i).out(j).shape)
                if strcmp(components(i).out(j).shape(k),'h')
                    if k == length(components(i).out(j).shape)
                        components(i).out(j).y(k) = components(i).out(j).y(k+1);
                    else
                        components(i).out(j).y(k+1) = components(i).out(j).y(k);
                    end
                elseif strcmp(components(i).out(j).shape(k),'v')
                    components(i).out(j).x(k+1) = components(i).out(j).x(k);
                end
            end
            % Plot the arrow using the flowArrow function
            components(i).out(j).arrowHandle = flowArrow(components(i).out(j),defaults);
            % Determine the string in the arrow
            arrowString = {[' ' components(i).out(j).flowNumber],...
                ['  ' num2str(round(components(i).out(j).value,defaults.roundDecimals)) ' ' defaults.units],...
                ['(' num2str(round(components(i).out(j).value./defaults.nominalValue.*100,defaults.roundDecimals)) '%)' ]};
            
            if components(i).out(j).ShowText ~=false
                % Place the text at the beginning of the arrow
                if contains(components(i).out(j).textLocation,'b')
                    t = text(components(i).out(j).x(1) + components(i).out(j).textShift(1),components(i).out(j).y(1) + components(i).out(j).textShift(2),...
                        arrowString,'FontSize',components(i).out(j).FontSize);
                end
            % Place the text in the center of the arrow
                if contains(components(i).out(j).textLocation,'c')
                    ii = length(components(i).out(j).y)/2 + [0 1];
                    t = text(mean(components(i).out(j).x(ii)) + components(i).out(j).textShift(1),mean(components(i).out(j).y(ii)) + components(i).out(j).textShift(2),...
                        arrowString,'HorizontalAlignment','center','Rotation',components(i).out(j).TextRotation,'FontSize',components(i).out(j).FontSize);
                end
                % Place the text at the end of the arrow
                if contains(components(i).out(j).textLocation,'e')
                    ii = length(components(i).out(j).y) + [-1 0];
                    t = text(components(i).out(j).x(end) + components(i).out(j).textShift(1),components(i).out(j).y(end) + components(i).out(j).textShift(2),...
                        arrowString,'HorizontalAlignment','right','FontSize',components(i).out(j).FontSize);
                end
                % Adjust alignment of the text
                if any(components(i).out(j).verticalAlignmentText=='at')
                    t.Position(2) = components(i).out(j).y(ii(1)) + max(components(i).out(j).value*defaults.norm_fact/2,defaults.minArrowWidth);
                elseif any(components(i).out(j).verticalAlignmentText=='bu')
                    t.Position(2) = components(i).out(j).y(ii(1)) - max(components(i).out(j).value*defaults.norm_fact/2,defaults.minArrowWidth);
                end
                if any(components(i).out(j).verticalAlignmentText=='tu')
                t.VerticalAlignment = 'top';
                elseif any(components(i).out(j).verticalAlignmentText=='ab')
                    t.VerticalAlignment = 'bottom';
                end
                % Save the handle of the text
                components(i).out(j).textHandle = t;
            end
        end
    end
end

% Plot all blocks
for i = 1:length(components)
    if components(i).drawBlock
        if components(i).checkBalance && max(components(i).width_in,components(i).width_out)/min(components(i).width_in,components(i).width_out)-1 > 1e-7
            c = 'r';
            lw = 2;
            warning(['Sum of input values (' num2str(components(i).width_in) ...
                ' ' defaults.units ') is not equal to sum of outputs (' ...
                num2str(components(i).width_out) ' ' defaults.units ...
                ') for block number ' num2str(i)])
        else
            c = 'k';
            lw = 1;
        end
        components(i).blockHandle = ...
            patch(components(i).coordinateX + [-1 1 1 -1]*components(i).blockWidth/2,...
            components(i).coordinateY + [-1 -1 1 1]*components(i).blockHeight/2,...
            components(i).FaceColor,'LineStyle','-','EdgeColor',c,'LineWidth',lw);
    end
    if isfield(components(i),'name') && ~isempty(components(i).name)
        components(i).blockTextHandle = ...
            text(components(i).coordinateX,components(i).coordinateY,...
            components(i).name,'HorizontalAlignment','center',...
            'VerticalAlignment','middle','FontSize',components(i).FontSize);
        if isfield(components(i),'TextRotation') && ~isempty(components(i).TextRotation)
            components(i).blockTextHandle.Rotation = components(i).TextRotation;
        end
    end
        
end
% Get outer plot positions
xl = [Inf -Inf];
yl = [Inf -Inf];
for i = 1:length(components)
    xl(1) = min(xl(1),components(i).coordinateX - components(i).blockWidth/2);
    xl(2) = max(xl(2),components(i).coordinateX + components(i).blockWidth/2);
    yl(1) = min(yl(1),components(i).coordinateY - components(i).blockHeight/2);
    yl(2) = max(yl(2),components(i).coordinateY + components(i).blockHeight/2);
    if isfield(components(i),'out') && ~isempty(components(i).out)
        for j = 1:length(components(i).out)
            xl(1) = min(xl(1),min(components(i).out(j).x) - max(components(i).out(j).value*defaults.norm_fact,defaults.minArrowWidth)/2);
            xl(2) = max(xl(2),max(components(i).out(j).x) + max(components(i).out(j).value*defaults.norm_fact,defaults.minArrowWidth)/2);
            yl(1) = min(yl(1),min(components(i).out(j).y) - max(components(i).out(j).value*defaults.norm_fact,defaults.minArrowWidth)/2);
            yl(2) = max(yl(2),max(components(i).out(j).y) + max(components(i).out(j).value*defaults.norm_fact,defaults.minArrowWidth)/2);
        end
    end
end
% axis equal
xl = xl + defaults.borderWidth([4 2]).*[-1 1];
yl = yl + defaults.borderWidth([3 1]).*[-1 1];
set(gca,'XLim',xl,...
    'YLim',yl,...
    'Position',[0 0 1 1],'Box','off','XTick',[],'YTick',[],'Visible','off');
fig.Color = [1 1 1];
fig.OuterPosition = defaults.figureSize;
drawnow
% adjust figure size to obtain equal scaling of x and y axis
if diff(yl)/diff(xl) > fig.InnerPosition(4)/fig.InnerPosition(3)
    fig.InnerPosition(3) = round(fig.InnerPosition(4)*diff(xl)/diff(yl));
else
    fig.InnerPosition(4) = round(fig.InnerPosition(3)*diff(yl)/diff(xl));
end
% Set figure to center of defaults.figureSize
fig.OuterPosition(1) = round(defaults.figureSize(1) + defaults.figureSize(3)/2 - fig.OuterPosition(3)/2);
fig.OuterPosition(2) = round(defaults.figureSize(2) + defaults.figureSize(4)/2 - fig.OuterPosition(4)/2);
axis equal