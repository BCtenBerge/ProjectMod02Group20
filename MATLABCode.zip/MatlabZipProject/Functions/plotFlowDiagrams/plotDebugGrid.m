grid on
set(gca,'Visible','on','Box','on')
xx = get(gca,'XLim');
yy = get(gca,'YLim');
dxy = [1000 500 100 50 10 5 1 0.5 0.1];
dx = dxy(find(diff(xx)./(5*(dxy))>1,1));
xx = (ceil(xx(1)/dx)*dx):dx:(floor(xx(2)/dx)*dx);
dy = dxy(find(diff(yy)./(5*(dxy))>1,1));
yy = (ceil(yy(1)/dy)*dy):dy:(floor(yy(2)/dy)*dy);
set(gca,'XTick',xx,'YTick',yy)
for i = 1:length(xx)
    text(xx(i),yy(1),num2str(xx(i)),'HorizontalAlignment','center','VerticalAlignment','bottom','Color',0.7*[1 1 1])
end
for i = 1:length(yy)
    text(xx(1),yy(i),num2str(yy(i)),'HorizontalAlignment','left','VerticalAlignment','baseline','Color',0.7*[1 1 1])
end
