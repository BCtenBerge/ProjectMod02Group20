% exampleDiagram.m
% v0.1: 25-07-2019
% v1.0: 19-12-2019
% Jos Havinga
% Draw (Sankey/Grassmann) flow diagram
% First build a structure containting all the blocks (i.e.
% furnaces, pumps, turbines, etc), including connections between blocks (in
% blocks(i).in (for inputs) and blocks(i).out (for outputs)
% The structure 'defaults' contains all default settings for the blocks and
% arrows (e.g. colors, line widths, font size, alignment, etc). Default 
% settings will be assigned to all blocks and arrows if not defined in the
% plant definition.

clear
close all

% Set default settings
% (Change defaultSettings script to adjust default settings)
defaultSettings;
defaults.nominalValue = 313.24;
defaults.norm_fact = 0.07;

% Create plant definition
% flow arrows always enter from left and leave at right side
components(1).coordinateX = 0;
components(1).coordinateY = -10;
components(1).referencePoint = 'b';
components(1).drawBlock = false;
components(1).out(1).target = 2;
    components(1).out(1).value = 313.24;

components(2).coordinateX = 50;
components(2).coordinateY = 'i1'; % inherit from source number 1
components(2).out(1).target = 5;
    components(2).out(1).value = 216.32;
    components(2).out(1).shape = 'hvh';
    components(2).out(1).verticalLinesX = 70;
    components(2).out(1).type = 'heat';
    components(2).out(1).TextRotation = 90;
components(2).out(2).target = 3;
    components(2).out(2).value = 209.43;
components(2).in(1).source = 1;
components(2).in(2).source = 3;

components(3).coordinateX = 100;
components(3).coordinateY = 'i1';
components(3).out(1).target = 4;
    components(3).out(1).value = 96.92;
components(3).out(2).target = 2;
    components(3).out(2).value = 112.51;
    components(3).out(2).shape = 'hvhvh';
    components(3).out(2).verticalLinesX = [120 30];
    components(3).out(2).horizontalLinesY = -30;
    components(3).out(2).type = 'electricity';
components(3).in(1).source = 2;

components(4).coordinateX = 150;
components(4).coordinateY = 'i1';
components(4).in(1).source = 3;
components(4).drawBlock = false;

components(5).coordinateX = 90;
components(5).coordinateY = 30;
components(5).in(1).source = 2;
components(5).drawBlock = false;

% Assing default values to plant structure
components = setDefaults(components,defaults,flowTypes);

% And plot the flow diagram
plotFlowDiagram;

plotDebugGrid; %optional