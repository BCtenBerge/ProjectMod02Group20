function arrowHandle = flowArrow(arrow,defaults)
% Plot a fully defined arrow. Requires the defaults structure.

% Get coordinates and width of the arrow
x = arrow.x(:);
y = arrow.y(:);
w = max(arrow.value*defaults.norm_fact,defaults.minArrowWidth);
arrow.tipAngle = tand(arrow.tipAngle);
if numel(arrow.tipAngle) == 1
    arrow.tipAngle = arrow.tipAngle*[1 1];
end

% Check that x- and y-coordinates are defined with horizontal and vertical
% lines only
if any(~(diff(x)==0 | diff(y)==0))
    error('Only horizontal and vertical lines allowed in Sankey diagram (check x and y coordinate vectors)')
end

% Get all coordinates of the contour of the arrow
np = length(x);
xx = [x(:) x(:) x(:)];
yy = [y(:) y(:) y(:)];
if x(2) > x(1) % start left to right
    xx(1,2) = xx(1,2) + sum(w)*arrow.tipAngle(1);
elseif x(2) < x(1) % start right to left
    xx(1,2) = xx(1,2) - sum(w)*arrow.tipAngle(1);
elseif y(2) > y(1) % start bottom to top
    yy(1,2) = yy(1,2) + sum(w)*arrow.tipAngle(1);
elseif y(2) < y(1) % start top to bttom
    yy(1,2) = yy(1,2) - sum(w)*arrow.tipAngle(1);
end

if x(end) > x(end-1) % end left to right
    xx(end,[1 3]) = xx(end,[1 3]) - sum(w)*arrow.tipAngle(2);
elseif x(end) < x(end-1) % end right to left
    xx(end,[1 3]) = xx(end,[1 3]) + sum(w)*arrow.tipAngle(2);
elseif y(end) > y(end-1) % end bottom to top
    yy(end,[1 3]) = yy(end,[1 3]) - sum(w)*arrow.tipAngle(2);
elseif y(end) < y(end-1) % end top to bttom
    yy(end,[1 3]) = yy(end,[1 3]) + sum(w)*arrow.tipAngle(2);
end




for i = 1:(np-1)
    if y(i) == y(i+1) % horizontal line
        if x(i+1) > x(i) % from left to right
            yy(i,[1 3]) = yy(i,[1 3]) + [-1 1]*sum(w)/2;
            yy(i+1,[1 3]) = yy(i+1,[1 3]) + [-1 1]*sum(w)/2;
        elseif x(i+1) < x(i) % from right to left
            yy(i,[1 3]) = yy(i,[1 3]) - [-1 1]*sum(w)/2;
            yy(i+1,[1 3]) = yy(i+1,[1 3]) - [-1 1]*sum(w)/2;
        end
    elseif x(i) == x(i+1) % vertical
        if y(i+1) > y(i) % from bottom to top
            xx(i,[1 3]) = xx(i,[1 3]) - [-1 1]*sum(w)/2;
            xx(i+1,[1 3]) = xx(i+1,[1 3]) - [-1 1]*sum(w)/2;
        elseif y(i+1) < y(i) % from top to bottom
            xx(i,[1 3]) = xx(i,[1 3]) + [-1 1]*sum(w)/2;
            xx(i+1,[1 3]) = xx(i+1,[1 3]) + [-1 1]*sum(w)/2;
        end
    end
end


% Plot the arrow
hold on
for i = 1:length(w)
    w_st = sum(w(1:(i-1)))/sum(w);
    w_end = sum(w(1:i))/sum(w);
    if w_st < 0.5 & w_end > 0.5
        w_mid = 0.5;
    else
        w_mid = (w_st + w_end)/2;
    end
    x_pl = 0*xx;
    y_pl = 0*yy;
    for j = 1:np
        x_pl(j,:) = interp1([0 0.5 1],xx(j,:),[w_st w_mid w_end]);
        y_pl(j,:) = interp1([0 0.5 1],yy(j,:),[w_st w_mid w_end]);
    end
    x_pl = [x_pl(:,1);x_pl(end,2);x_pl(end:(-1):1,3);x_pl(1,2)];
    y_pl = [y_pl(:,1);y_pl(end,2);y_pl(end:(-1):1,3);y_pl(1,2)];
    arrowHandle = patch(x_pl,y_pl,arrow.color,'LineStyle',arrow.LineStyle,'LineWidth',arrow.LineWidth,'FaceAlpha',arrow.FaceAlpha);
end


end