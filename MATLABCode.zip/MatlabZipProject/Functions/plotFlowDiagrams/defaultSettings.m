% set Default Settings for Sankey/Grassmann diagrams

components = struct('name',{},'in',{},'out',{},'width_in',{},'width_out',{},'coordinateX',{},'coordinateY',{},'referencePoint',{},...
    'inputsAlignment',{},'outputsAlignment',{},'checkBalance',{},...
    'drawBlock',{},'blockHeight',{},'blockWidth',{},'FontSize',{},'TextRotation',{},'FaceColor',{},'flowNumber',{},'ShowText',{},'arrowString',{});

%% General default settings
% Units of flows
defaults.units = 'MW';
% Normalization in plots (conversion from flow values to coordinates)
defaults.norm_fact = 0.05;
% Border around figure
defaults.borderWidth = [10 10 10 10]; % [top right bottom left]
% Figure size (will be adjusted at the end of plotFlowDiagram script)
defaults.figureSize = get(0,'ScreenSize')+[0 40 0 -40];
% Minimum width of an plotted arrow (if the calculated widht of an arrow is
% smaller than the minArrowWidth, it will be plotted with the minArrowWidth
defaults.minArrowWidth = 0.5;
% For calculating the percentage of flow with respect to the heat input
defaults.nominalValue = 1;

%% Default settings for all blocks
% Check whether sum(inputs) equals to sum(outputs)
% If false, block is drawn with red arrow and warning is given
defaults.checkBalance = false;
% Whether blocks must be drawn
defaults.drawBlock = true;
% Number of decimals for rounding numbers
defaults.roundDecimals = 1;
% Default block width
defaults.blockWidth = 10;
% Default rotation of text within block
defaults.TextRotation = 90;
% Default font size for text in block
defaults.FontSize = 20;
% Default face color
defaults.FaceColor = 0.95*[1 1 1];
% reference point for assigned block coordinates (top, center or bottom)
defaults.referencePoint = 'c'; % 't' (top) or 'c' (center) or 'b' (bottom)
% Alignment of input flows with respect to block height (top, center or
% bottom)
defaults.inputsAlignment = 'c'; % 't' (top) or 'c' (center) or 'b' (bottom)
% Alignment of output flows with respect to block height (top, center or
% bottom)
defaults.outputsAlignment = 'c'; % 't' (top) or 'c' (center) or 'b' (bottom)

%% Default settings for arrows
% Shape of arrow, only horizontal line by default
defaults.out.shape = 'h';
% Position of text (flow values) with respect to arrow position (at the
% begin, center, or end of arrow)
defaults.out.textLocation = 'c'; % 'b (begin) or 'c' (center) or 'e' (end)
% Rotation of arrow text (flow values, only used if out.textLocation is set to 'c')
defaults.out.TextRotation = 0; 
% Shift of arrow text (use it in the definition file to adjust positioning
% of arrow texts)
defaults.out.textShift = [0 0]; % text shift in x and y direction
% Vertical alignment text with respect to arrow
% 'a' = text (a)bove arrow
% 't' = text inside arrow aligned at the (t)op
% 'c' = text in (c)enter of arrow
% 'b' = text inside arrow aligned at the (b)ottom
% 'u' = text (u)nder arrow
defaults.out.verticalAlignmentText = 'c';
% Font Size
defaults.out.FontSize = defaults.FontSize;
% Default flow type. By default, the color of this flow type will be
% assigned to the arrows
defaults.out.type = 'superheated vapor';
% Line style (use 'none' to draw without lines
defaults.out.LineStyle = '-';
% Line Width
defaults.out.LineWidth = 1;
% Transparency of arrows. Value in between 0 (fully transparent) and 1 (not
% transparent)
defaults.out.FaceAlpha = 1;
% Angle of arrow tip (in degrees)
% Assign a [1x2] vector to use different angle for front and back of arrows
defaults.out.tipAngle = 10;
defaults.out.flowNumber = 0;
defaults.out.ShowText = true;
defaults.out.arrowString= NaN;
%% Set colors for different flows
flowTypes(1).type = 'compressed liquid';
flowTypes(1).color = [65 115 255]./255;
flowTypes(2).type = 'saturated liquid';
flowTypes(2).color = [115 171 255]./255;
flowTypes(3).type = 'mixture';
flowTypes(3).color = [172 206 255]./255;
flowTypes(4).type = 'saturated vapor';
flowTypes(4).color = [230 240 255]/255;
flowTypes(5).type = 'superheated vapor';
flowTypes(5).color = [230 241 255]/255;
flowTypes(6).type = 'electricity';
flowTypes(6).color = [160 202 83]/255;
flowTypes(7).type = 'heat';
flowTypes(7).color = [255 128 128]/255;
flowTypes(8).type = 'energy loss';
flowTypes(8).color = [255 255 77]/255;
flowTypes(9).type = 'work';
flowTypes(9).color = [255 179 102]/255;
flowTypes(10).type = 'gas';
flowTypes(10).color = [255 255 255]/255;
flowTypes(11).type = 'Thermal input';
flowTypes(11).color = [0.7 0.5 0.8];