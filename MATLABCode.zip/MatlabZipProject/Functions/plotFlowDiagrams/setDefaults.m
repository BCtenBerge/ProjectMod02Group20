function components = setDefaults(components,defaults,flowTypes)
% This function is used as part of the code for plotting Sankey and
% Grassmann diagrams. When components are defined, all properties will be
% assigned in this function using the defaults structure. If a property is
% already set in components, it will not change. Otherwise, the default
% value for that property will be set.

% Get the list of field names of the defaults structure
level1fields = fieldnames(defaults);
for ifield1 = 1:length(level1fields)
    % If the fieldname is not equal to 'in' or 'out'
    if ~strcmpi(level1fields{ifield1},'out') && ~strcmpi(level1fields{ifield1},'in')
        % For each component
        for iblock = 1:length(components)
            % If the specific fiels is not set, assign the default value
            if ~isfield(components(iblock),level1fields{ifield1}) || ...
                    isempty(components(iblock).(level1fields{ifield1}))
                components(iblock).(level1fields{ifield1}) = defaults.(level1fields{ifield1});
            end
        end
    else
        % For all the subfields of the in and out field
        level2fields = fieldnames(defaults.(level1fields{ifield1}));
        % For each component
        for iblock = 1:length(components)
           for i_in_out = 1:length(components(iblock).(level1fields{ifield1}))
               % For each subfield
                for ifield2 = 1:length(level2fields)
                    if ~isfield(components(iblock).(level1fields{ifield1})(i_in_out),level2fields{ifield2}) ||...
                            isempty(components(iblock).(level1fields{ifield1})(i_in_out).(level2fields{ifield2}))
                        components(iblock).(level1fields{ifield1})(i_in_out).(level2fields{ifield2}) = ...
                            defaults.(level1fields{ifield1}).(level2fields{ifield2});
                    end
                end
           end
        end     
    end
end
% set arrow colors
for iflowtype = 1:length(flowTypes)
    for i = 1:length(components)
        for j = 1:length(components(i).out)
            if ~isfield(components(i).out(j),'color') || isempty(components(i).out(j).color)
                components(i).out(j).color = ...
                    flowTypes(find(strcmpi({flowTypes(:).type},components(i).out(j).type))).color;
            end
        end
    end
end
end

