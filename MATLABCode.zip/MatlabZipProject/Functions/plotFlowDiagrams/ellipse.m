function el = ellipse(a, b, h, k, angle,color_el)
    % a: Semi-major axis
    % b: Semi-minor axis
    % h, k: Center of the ellipse
    % angle: Rotation angle in degrees

    % if ~exist('defaults','var')
    %     defaultsSettings
    % end
    % 
    % components = setDefaults(components,defaults,flowTypes);

    theta = linspace(0, 2*pi, 100); % Parameter to trace the ellipse

    % Parametric equations for the rotated ellipse
    x = a * cos(theta);
    y = b * sin(theta);

    % Rotation matrix for the ellipse
    R = [cosd(angle) -sind(angle); sind(angle) cosd(angle)];

    % Apply rotation and translation
    coords = R * [x; y];
    x_rot = coords(1, :) + h;
    y_rot = coords(2, :) + k;

    % Plot the ellipse
    el = fill(x_rot, y_rot,color_el);

    % Plot text in ellipse
    % for i = 1:length(components)
    %     for j = 1:length(components(i).out)
    %         elstring = {[' ' components(i).out(j).flowNumber],...
    %             ['  ' num2str(round(components(i).out(j).value,defaults.roundDecimals)) ' ' defaults.units],...
    %             ['(' num2str(round(components(i).out(j).value./defaults.nominalValue.*100,defaults.roundDecimals)) '%)' ]};
    %     end
    % end
    % el.text = text(h,k,elstring,'Rotation',90);
    hold on
end