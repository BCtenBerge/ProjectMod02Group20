function [T,p,h,s,x] = turbineProperties(p_in,h_in,isentropic_eff,p_out,n_steps)
% Gathering all properties of a turbine

%   Detailed explanation goes here
p = linspace(p_in,p_out,n_steps);
T = NaN(size(p));
h = NaN(size(p));
s = NaN(size(p));
x = NaN(size(p));

h(1) = h_in;
T(1) = XSteam('t_ph', p(1), h(1));
s(1) = XSteam('s_ph', p(1), h(1));
x(1) = XSteam('x_ph', p(1), h(1));

for i=2:n_steps
    h_out_isentropic = XSteam('h_ps', p(i), s(1));
    h(i) = h(1) - isentropic_eff * (h(1) - h_out_isentropic);
    T(i) = XSteam('t_ph',p(i),h(i));
    s(i) = XSteam('s_ph',p(i),h(i));
    x(i) = XSteam('x_ph',p(i),h(i));
end



end