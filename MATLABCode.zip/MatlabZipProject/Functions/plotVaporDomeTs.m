function plotHandle = plotVaporDomeTs
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here

T = linspace(0.01,500,1000);
sV = zeros(1, length(T));
sL = zeros(1, length(T));

for i=1:length(T)
    sV(i) = XSteam('sV_T', T(i));
    sL(i) = XSteam('sL_T', T(i));
end

isnV = ~isnan(sV);
isnL = ~isnan(sL);


sData = [sL(isnV), fliplr(sV(isnV))];
tData = [T(isnL), fliplr(T(isnV))];

plotHandle = plot(sData,tData,'b',LineWidth=0.5);
xlabel('entropy (kJ/kgK')
ylabel('Temperature (C)')
axis([0 10 0 400])
end