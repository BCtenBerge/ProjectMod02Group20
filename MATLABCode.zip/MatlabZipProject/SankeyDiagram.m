clc,clear, close all
% Bram ten Berge, Jasper Koot - December 2024

% Adding the plotflowDiagrams function, made by Jos Havinga.
addpath Functions\plotFlowDiagrams\

% Defining some default settings 
defaultSettings
defaults.out.TextRotation=90;
defaults.blockWidth=300;
defaults.FontSize=12;
defaults.out.FontSize=defaults.FontSize;
defaults.minArrowWidth=0.1;
defaults.norm_fact=3;
defaults.referencePoint='b';
defaults.out.FaceAlpha=0.9;
h=9; % These two variables are only made to enlarge all coordinates in x- and y direction to create more space.
p=3;



%% thermal input/block 1
components(1).coordinateX=-100*h;
components(1).coordinateY=0*p;
components(1).drawBlock=false;
components(1).out(1).value=556.2;
components(1).out(1).target=2;
components(1).out(1).type='Thermal Input';
components(1).out(1).flowNumber='1:';

components(14).coordinateX=-100*h;
components(14).coordinateY=556.2*p;
components(14).drawBlock=false;
components(14).out(1).value=105.9;
components(14).out(1).target=2;
components(14).out(1).type='Thermal Input';
components(14).out(1).flowNumber='13:';
components(14).out(1).ShowText=false;


%% steam seperators
components(2).coordinateX=250*h;
components(2).coordinateY=0*p;
components(2).name='Steam Seperators';
components(2).in(1).source=1;
components(2).in(2).source=14;
%steam seperator to turbine 1
components(2).out(4).value=227.4;
components(2).out(4).target=3;
components(2).out(4).type='saturated vapor';
components(2).out(4).flowNumber='3:';
components(2).out(4).textShift=[0 -110*p];
components(2).out(4).ShowText=false;
%steam seperator to turbine 2
components(2).out(3).value=388.8;
components(2).out(3).target=4;
components(2).out(3).type='saturated vapor';
components(2).out(3).flowNumber='12 & 14:';
%steam seperator loss
components(2).out(1).value=43.2;
components(2).out(1).target=9;
components(2).out(1).type='heat';
components(2).out(1).shape='hvhvh';
components(2).out(1).verticalLinesX=[300*h 900*h];
components(2).out(1).horizontalLinesY=1400*p;
components(2).out(1).flowNumber='19 & 21:';
components(2).out(1).ShowText=false;
%to the dearator
components(2).out(2).value=2.8;
components(2).out(2).target=12;
components(2).out(2).type='saturated vapor';
components(2).out(2).shape='hvhvh';
components(2).out(2).verticalLinesX=[500*h 1200*h];
components(2).out(2).horizontalLinesY=1200*p;
components(2).out(2).textShift= [400*h -150*p];
components(2).out(2).flowNumber='11:';
components(2).out(2).ShowText=false;

%% turbine 1
components(3).coordinateX=500*h;
components(3).coordinateY=0*p;
components(3).in(1).source=2;
components(3).name='T1';
%turbine to generator
components(3).out(2).value=40;
components(3).out(2).target=13;
components(3).out(2).type='work';
components(3).out(2).textShift=[80*h -150*p];
components(3).out(2).ShowText=false;
%turbine to condenser
components(3).out(1).value=187.4;
components(3).out(1).target=7;
components(3).out(1).type='mixture';
components(3).out(1).shape='hvh';
components(3).out(1).verticalLinesX=670*h;
components(3).out(1).textShift=[-90*h -15*p];
components(3).out(1).FontSize=7.5;
components(3).out(1).flowNumber='4:';
components(3).out(1).ShowText=false;


%% turbine 2
components(4).coordinateX=500*h;
components(4).coordinateY=components(2).out(4).value*p;
components(4).in(1).source=2;
components(4).name='T2';
%turbine to generator
components(4).out(2).value=60.0;
components(4).out(2).target=13;
components(4).out(2).type='work';
components(4).out(2).shape='hvh';
components(4).out(2).verticalLinesX=650*h;
components(4).out(2).textShift=[-2*h 8*p];
components(4).out(2).FontSize=8;
components(4).out(2).ShowText=false;
%turbine to condenser
components(4).out(1).value=328.8;
components(4).out(1).target=6;
components(4).out(1).type='mixture';
components(4).out(1).shape='hvh';
components(4).out(1).verticalLinesX=600*h;
components(4).out(1).textShift=[-40*h -55*p];
components(4).out(1).flowNumber='15:';


%% generators
components(13).coordinateX=750*h;
components(13).coordinateY=0*p;
components(13).in(1).source=4;
components(13).in(2).source=3;
components(13).name='G';
%electricity generated
components(13).out(4).value=95;
components(13).out(4).target=8;
components(13).out(4).type='electricity';
components(13).out(4).shape='hvh';
components(13).out(4).verticalLinesX=1250*h;
components(13).out(4).textShift=[0 6*p];
%To thermal power loss
components(13).out(1).value=3;
components(13).out(1).target=9;
components(13).out(1).type='heat';
components(13).out(1).shape='hvh';
components(13).out(1).verticalLinesX=880*h;
components(13).out(1).textShift=[-50*h 780*p];
components(13).out(1).ShowText=false;
%to pump 1
components(13).out(2).value=1.7;
components(13).out(2).target=10;
components(13).out(2).type='electricity';
components(13).out(2).shape='hvhvh';
components(13).out(2).verticalLinesX=[800*h 220*h];
components(13).out(2).horizontalLinesY=1600*p;
components(13).out(2).textShift=[0 650*p];
components(13).out(2).ShowText=false;
%to pump 2
components(13).out(3).value=0.3;
components(13).out(3).target=5;
components(13).out(3).type='electricity';
components(13).out(3).shape='hvhvh';
components(13).out(3).verticalLinesX=[1000*h 1450*h];
components(13).out(3).horizontalLinesY=-200*p;
components(13).out(3).textShift=[225*h 100*p];
components(13).out(3).ShowText=false;


%% condenser 1
components(7).coordinateX=750*h;
components(7).coordinateY=(components(3).out(2).value+components(4).out(2).value)*p;
components(7).in(2).source=3;
components(7).in(1).source=11;
components(7).name='C1';
%To cooling tower
components(7).out(1).value=357.3; 
components(7).out(1).target=11;
components(7).out(1).type='compressed liquid';
components(7).out(1).shape='hvhvh';
components(7).out(1).verticalLinesX=[874*h -280*h];
components(7).out(1).horizontalLinesY=-600*p;
components(7).out(1).flowNumber='9:';
%To the dearator
components(7).out(2).value=15.7;
components(7).out(2).target=12;
components(7).out(2).type='saturated liquid';
components(7).out(2).shape='hvh';
components(7).out(2).verticalLinesX=850*h;
components(7).out(2).textShift=[270*h 140*p];
components(7).out(2).flowNumber='5`:';
components(7).out(2).ShowText=false;

%% condenser 2
components(6).coordinateX=750*h;
components(6).coordinateY=(components(3).out(1).value+components(3).out(2).value+components(4).out(2).value+185.7)*p;
components(6).in(2).source=4;
components(6).in(1).source=10;
components(6).name='C2';
%To the dearrator
components(6).out(1).value=645.1;
components(6).out(1).target=12;
components(6).out(1).type='compressed liquid';
components(6).out(1).shape='hvh';
components(6).out(1).verticalLinesX=1050*h;
components(6).out(1).flowNumber='16:';
components(6).out(1).textShift=[-60*h 30*p];


%% total electricity output
components(8).coordinateX=1500*h;
components(8).coordinateY=-500*p;
components(8).in(1).source=13;
components(8).name='';
components(8).FaceColor=[160 202 83]/255;
components(8).drawBlock=false;


%% total heat loss
components(9).coordinateX=1500*h;
components(9).coordinateY=(2000-(32.6+3+43.2))*p;
components(9).blockWidth=900;
components(9).in(1).source=11;
components(9).in(2).source=2;
components(9).in(3).source=13;
components(9).in(4).source=12;
components(9).name='567.2 MW';
components(9).FaceColor=[255 128 128]/255;


%% Pump 1
components(10).coordinateX=250*h;
components(10).coordinateY=(1500+185.7-1.7)*p;
components(10).in(1).source=11;
components(10).in(2).source=13;
components(10).name='Pump 1';
%to condenser 2
components(10).out(1).value=316.4;
components(10).out(1).target=6;
components(10).out(1).type='compressed liquid';
components(10).out(1).shape='hvh';
components(10).out(1).verticalLinesX=500*h;
components(10).out(1).flowNumber='18:';
components(10).out(1).textShift=[-5*h 0*p];


%% Cooling tower
components(11).coordinateX=0*h;
components(11).coordinateY=1500*p;
components(11).in(1).source=5;
components(11).in(2).source=7;
components(11).name='Cooling Tower';
%to condenser 1
components(11).out(3).value=185.7;
components(11).out(3).target=7;
components(11).out(3).type='compressed liquid';
components(11).out(3).shape='hvhvh';
components(11).out(3).verticalLinesX=[350*h 650*h];
components(11).out(3).horizontalLinesY=800*p;
components(11).out(3).flowNumber='8:';
components(11).out(3).textShift=[-135*h 250*p];
%to pump 1
components(11).out(2).value=314.7;
components(11).out(2).target=10;
components(11).out(2).type='compressed liquid';
components(11).out(2).flowNumber='17:';
components(11).out(2).textShift= [0*h 20*p];
%heat loss
components(11).out(1).value=488.4;
components(11).out(1).target=9;
components(11).out(1).type='heat';


%% Dearator
components(12).coordinateX=1300*h;
components(12).coordinateY=97*p;
components(12).name='Dearator';
components(12).in(1).source=2;
components(12).in(2).source=6;
components(12).in(3).source=7;
%to pump 2
components(12).out(2).value=631.1;
components(12).out(2).target=5;
components(12).out(2).type='compressed liquid';
components(12).out(2).flowNumber='6:';
%heat loss
components(12).out(1).value=32.6;
components(12).out(1).target=9;
components(12).out(1).type='heat';
components(12).out(1).shape='hvh';
components(12).out(1).verticalLinesX=1400*h;
components(12).out(1).textShift=[-30*h 0];
components(12).out(1).ShowText=false;


%% Pump 2
components(5).coordinateX=1500*h;
components(5).coordinateY=95*p;
components(5).in(1).source=12;
components(5).in(2).source=13;
components(5).name='Pump 2';
%to the cooling tower
components(5).out(1).value=631.4;
components(5).out(1).target=11;
components(5).out(1).type='compressed liquid';
components(5).out(1).shape='hvhvh';
components(5).out(1).verticalLinesX=[1700*h -240*h];
components(5).out(1).horizontalLinesY=3100*p;
components(5).out(1).flowNumber='7:';

defaults.nominalValue=662.2;
plotFlowDiagram


%% Adding ellipses using ellipse function

for i=1:length(components)
    if isfield(components(i),'out') && ~isempty(components(i).out)
        for j=1:length(components(i).out)
            components(i).out(j).arrowString = {
                [' ' components(i).out(j).flowNumber],...
                ['  ' num2str(round(components(i).out(j).value,defaults.roundDecimals)) ' ' defaults.units],...
                ['(' num2str(round(components(i).out(j).value./defaults.nominalValue.*100,defaults.roundDecimals)) '%)' ]
                };
        end
    end
end

% Thermal input
el(1) = ellipse(750,550,500,-500,90,[0.7 0.5 0.8]);
text(500,-500,components(14).out(1).arrowString,'Rotation',90,'HorizontalAlignment','center', 'FontSize',12)

% Steam sep to T1
el(2) = ellipse(750,550,3550,-500,90,[230 240 255]/255);
text(3500,-500,components(2).out(4).arrowString,'Rotation',90,'HorizontalAlignment','center', 'FontSize',12)

% T1 to gen
el(3) = ellipse(600,400,5700,-580,90,[255 179 102]./255);
text(5525,-600,components(3).out(2).arrowString,'Rotation',90,'HorizontalAlignment','center', 'FontSize',12)

% Gen to P2
el(4) = ellipse(600,400,10125,-1000,90,[160 202 83]./255);
text(10000,-1000,components(13).out(3).arrowString,'Rotation',90,'HorizontalAlignment','center', 'FontSize',12)

% Dearator to Heat loss
el(5) = ellipse(700,500,12620,4000,90,[255 128 128]./255);
text(12500,4000,components(12).out(1).arrowString,'Rotation',90,'HorizontalAlignment','center', 'FontSize',12)

% Steam sep to dearator
el(6) = ellipse(750,750,11240,3600,90,[230 240 255]/255);
text(11200,3600,components(2).out(2).arrowString,'Rotation',90,'HorizontalAlignment','center', 'FontSize',12)

% Gens to p1
el(7) = ellipse(600,400,6750,5100,90,[160 202 83]./255);
text(6600,5100,components(13).out(2).arrowString,'Rotation',90,'HorizontalAlignment','center', 'FontSize',12)

% Steam sep to loss
el(8) = ellipse(750,550,5700,4200,90,[255 128 128]./255);
text(5700,4200,components(2).out(1).arrowString,'Rotation',90,'HorizontalAlignment','center', 'FontSize',12)

% Gen to heat loss
el(9) = ellipse(600,400,7600,5300,90,[255 128 128]./255);
text(7450,5300,components(13).out(1).arrowString,'Rotation',90,'HorizontalAlignment','center', 'FontSize',12)

% C1 to Dearator
el(10)= ellipse(750,550,10250,1045,90,[115 171 255]./255);
text(10200,950,components(7).out(2).arrowString,'Rotation',90,'HorizontalAlignment','center', 'FontSize',12)

% Net electricity output
el(11)= ellipse(900,620,13900,-1350,90,[160 202 83]/255);
text(13900,-1350,'Output 95MW','Rotation',90,'HorizontalAlignment','center', 'FontSize',12)
text(13650,-1350,'Net Electricity','Rotation',90,'HorizontalAlignment','center', 'FontSize',12)
text(14150,-1350,'(14.3%)','Rotation',90,'HorizontalAlignment','center', 'FontSize',12)

% T2 to Gens
el(12) = ellipse(600,400,6400,-460,90,[255 179 102]./255);
text(6225,-480,components(4).out(2).arrowString,'Rotation',90,'HorizontalAlignment','center', 'FontSize',12)

% T1 to C1
el(13) = ellipse(600,500,4900,-460,90,[172 206 255]./255);
text(4800,-480,components(3).out(1).arrowString,'Rotation',90,'HorizontalAlignment','center', 'FontSize',10)


% Extra text for heat loss block
text(13230,6650,'Heat loss','Rotation',90,'HorizontalAlignment','center', 'FontSize',12);
text(13750,6650,'(85.7%)','Rotation',90,'HorizontalAlignment','center', 'FontSize',12);

%% Legend
subset = [
    components(1).out(1).arrowHandle, ...
    components(2).out(1).arrowHandle, ...
    components(2).out(2).arrowHandle, ...
    components(4).out(1).arrowHandle, ...
    components(7).out(2).arrowHandle, ...
    components(5).out(1).arrowHandle, ...
    components(4).out(2).arrowHandle, ...
    components(13).out(2).arrowHandle ...
    ];

legend(subset,'Thermal Input','Heat','Saturated Vapor','Mixture','Saturated Liquid','Compressed Liquid','Work','Electricity','Orientation','horizontal');

% plotDebugGrid





